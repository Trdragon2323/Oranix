import "dotenv/config";
import express from "express";
import { createServer } from "http";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { publicPlatformScript } from "./publicConfig";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";
import { getEventMarkets, getLiveSoccerOdds, getSoccerScores } from "../odds-api";

async function startServer() {
  const app = express();
  const server = createServer(app);
  // Configure body parser with larger size limit for file uploads
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  app.get("/api/health", (_req, res) => res.json({ status: "ok" }));
  app.get("/api/odds/soccer", async (_req, res) => {
    try {
      const result = await getLiveSoccerOdds();
      res.set("Cache-Control", "no-store").json({ source: "The Odds API", ...result });
    } catch (error) {
      console.error("[Odds API] Failed to load live soccer odds:", error instanceof Error ? error.message : error);
      res.status(502).json({ source: "The Odds API", error: "Canlı futbol verisi şu anda alınamadı." });
    }
  });
  app.get("/api/odds/event", async (req, res) => {
    const sportKey = String(req.query.sportKey || "");
    const eventId = String(req.query.eventId || "");
    if (!sportKey || !eventId) return res.status(400).json({ error: "sportKey ve eventId gerekli." });
    try {
      const result = await getEventMarkets(sportKey, eventId);
      res.set("Cache-Control", "no-store").json({ source: "The Odds API", ...result });
    } catch (error) {
      console.error("[Odds API] Failed to load event markets:", error instanceof Error ? error.message : error);
      res.status(502).json({ source: "The Odds API", error: "Bu maç için ek market verisi alınamadı." });
    }
  });
  app.get("/api/odds/scores", async (req, res) => {
    const sportKeys = String(req.query.sports || "soccer_turkey_super_league").split(",").filter(Boolean);
    try {
      const result = await getSoccerScores(sportKeys);
      res.set("Cache-Control", "no-store").json({ source: "The Odds API", ...result });
    } catch (error) {
      console.error("[Odds API] Failed to load scores:", error instanceof Error ? error.message : error);
      res.status(502).json({ source: "The Odds API", error: "Canlı skorlar şu anda alınamadı." });
    }
  });
  app.get("/api/platform/config.js", (_req, res) => {
    res.set("Cache-Control", "no-store").type("application/javascript").send(publicPlatformScript());
  });
  registerOAuthRoutes(app);
  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const port = Number(process.env.PORT || "3000");
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error("Invalid PORT");
  server.on("error", error => { console.error("Server failed:", error.message); process.exit(1); });
  server.listen(port, "0.0.0.0", () => console.log(`Server listening on port ${port}`));
}

startServer().catch(error => { console.error(error); process.exit(1); });
