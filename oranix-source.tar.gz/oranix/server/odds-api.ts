type OddsApiSport = {
  key: string;
  group?: string;
  title?: string;
  active?: boolean;
  has_outrights?: boolean;
};

type OddsApiOutcome = {
  name: string;
  price: number;
  point?: number;
  description?: string;
};

type OddsApiMarket = {
  key: string;
  outcomes?: OddsApiOutcome[];
};

type OddsApiBookmaker = {
  key: string;
  title: string;
  markets?: OddsApiMarket[];
};

type OddsApiEvent = {
  id: string;
  sport_key: string;
  sport_title: string;
  commence_time: string;
  home_team: string;
  away_team: string;
  bookmakers?: OddsApiBookmaker[];
};

type OddsApiScore = {
  id: string;
  sport_key: string;
  sport_title: string;
  commence_time: string;
  completed: boolean;
  home_team: string;
  away_team: string;
  scores?: Array<{ name: string; score: string }> | null;
  last_update?: string | null;
};

type ApiMatch = {
  id: number;
  providerId?: string;
  sportKey?: string;
  country: string;
  league: string;
  level: string;
  kickoff: string;
  time: string;
  home: string;
  away: string;
  homeCode: string;
  awayCode: string;
  homeColor: string;
  awayColor: string;
  homePct: number;
  drawPct: number;
  awayPct: number;
  recommendation: string;
  market: "Maç Sonucu";
  odds: number;
  confidence: number;
  risk: "Düşük" | "Dengeli" | "Yüksek";
  form: string;
  note: string;
  trend: number[];
  source: "LIVE";
};

type ApiQuote = { name: string; price: number; point?: number };
export type ApiMarket = { key: string; title: string; quotes: ApiQuote[] };

type LiveOddsResult = {
  matches: ApiMatch[];
  sportsCount: number;
  remaining: string | null;
};

const ODDS_API_URL = "https://api.the-odds-api.com/v4";
const REQUEST_TIMEOUT_MS = 12_000;
const LIVE_CACHE_TTL_MS = 5 * 60 * 1000;
const REQUEST_BATCH_SIZE = 2;
const REQUEST_BATCH_DELAY_MS = 700;
const RATE_LIMIT_RETRY_DELAY_MS = 2_000;
let liveCache: { expiresAt: number; result: LiveOddsResult } | null = null;

function slugCode(name: string) {
  return name.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-zA-Z0-9]/g, "").slice(0, 3).toUpperCase() || "FC";
}

function hashId(value: string) {
  let hash = 0;
  for (let index = 0; index < value.length; index += 1) hash = (hash * 31 + value.charCodeAt(index)) | 0;
  return Math.abs(hash) || 1;
}

function titleParts(title: string) {
  const cleanTitle = title.replace(/^Soccer:\s*/i, "").trim();
  const normalized = cleanTitle.toLocaleLowerCase("en-US");
  if (normalized.includes("turkey super league")) return { league: "Süper Lig", level: "1. Lig" };
  const secondTier = /(2|second|championship|segunda|serie b|ligue 2|bundesliga 2|division 2|league 1)/.test(normalized);
  return { league: cleanTitle || "Futbol", level: secondTier ? "2. Lig" : "1. Lig" };
}

function countryFromLeague(title: string) {
  const clean = title.replace(/^Soccer:\s*/i, "");
  const country = clean.split(":")[0]?.trim() || "Global";
  return /^turkey$/i.test(country) ? "Türkiye" : country;
}

function dateLabel(iso: string) {
  const date = new Date(iso);
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const day = new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime();
  const dayDifference = Math.round((day - today) / 86_400_000);
  if (dayDifference === 0) return "Bugün";
  if (dayDifference === 1) return "Yarın";
  return new Intl.DateTimeFormat("tr-TR", { day: "2-digit", month: "short" }).format(date);
}

function oddsApiTime(date: Date) {
  return date.toISOString().replace(/\.\d{3}Z$/, "Z");
}

function toProbability(price: number) {
  return price > 1 ? 1 / price : 0;
}

function firstMarket(event: OddsApiEvent, key: string) {
  return event.bookmakers?.flatMap((bookmaker) => bookmaker.markets ?? []).find((market) => market.key === key);
}

function buildLiveMatch(event: OddsApiEvent): ApiMatch | null {
  const h2h = firstMarket(event, "h2h");
  if (!h2h?.outcomes?.length) return null;
  const outcomeByName = new Map(h2h.outcomes.map((outcome) => [outcome.name, outcome.price]));
  const homeOdds = outcomeByName.get(event.home_team);
  const awayOdds = outcomeByName.get(event.away_team);
  const drawOdds = outcomeByName.get("Draw") ?? outcomeByName.get("Beraberlik");
  if (!homeOdds || !awayOdds) return null;
  const raw = [toProbability(homeOdds), toProbability(drawOdds ?? 0), toProbability(awayOdds)];
  const total = raw.reduce((sum, value) => sum + value, 0) || 1;
  const [homePct, drawPct, awayPct] = raw.map((value) => Math.round((value / total) * 100));
  const maxPct = Math.max(homePct, drawPct, awayPct);
  const recommendation = maxPct === homePct ? `${event.home_team} kazanır` : maxPct === awayPct ? `${event.away_team} kazanır` : "Beraberlik";
  const confidence = Math.min(96, Math.max(57, Math.round(48 + maxPct * 0.62)));
  const risk = confidence >= 84 ? "Düşük" : confidence >= 72 ? "Dengeli" : "Yüksek";
  const { league, level } = titleParts(event.sport_title);
  const kickoffDate = new Date(event.commence_time);
  const time = new Intl.DateTimeFormat("tr-TR", { hour: "2-digit", minute: "2-digit", hour12: false }).format(kickoffDate);
  const price = maxPct === homePct ? homeOdds : maxPct === awayPct ? awayOdds : drawOdds ?? 0;
  return {
    id: hashId(event.id), providerId: event.id, sportKey: event.sport_key, country: countryFromLeague(event.sport_title), league, level,
    kickoff: dateLabel(event.commence_time), time, home: event.home_team, away: event.away_team,
    homeCode: slugCode(event.home_team), awayCode: slugCode(event.away_team), homeColor: "#78a9d4", awayColor: "#e44f5b",
    homePct, drawPct, awayPct, recommendation, market: "Maç Sonucu", odds: Number(price.toFixed(2)), confidence, risk,
    form: "Canlı oran", note: "The Odds API h2h oranlarından normalize edilen piyasa olasılığı. Takım formu ve kadro verisi bu sağlayıcıdan gelmez.",
    trend: [42, 47, 45, 53, 50, 58, Math.min(86, maxPct)], source: "LIVE",
  };
}

function bestMarkets(event: OddsApiEvent): ApiMarket[] {
  const markets = new Map<string, ApiMarket>();
  for (const bookmaker of event.bookmakers ?? []) {
    for (const market of bookmaker.markets ?? []) {
      if (markets.has(market.key) || !market.outcomes?.length) continue;
      const title = market.key === "totals" ? "Maç Alt/Üst" : market.key === "totals_h1" ? "İlk Yarı Alt/Üst" : market.key === "totals_h2" ? "İkinci Yarı Alt/Üst" : market.key === "h2h_3_way_h1" ? "İlk Yarı Sonucu" : market.key === "h2h_3_way_h2" ? "İkinci Yarı Sonucu" : market.key === "btts" ? "Karşılıklı Gol" : "Maç Sonucu";
      markets.set(market.key, { key: market.key, title, quotes: market.outcomes.map((outcome) => ({ name: outcome.name, price: outcome.price, point: outcome.point })) });
    }
  }
  return Array.from(markets.values());
}

async function oddsApiGet<T>(path: string, apiKey: string, params: Record<string, string>) {
  const url = new URL(`${ODDS_API_URL}${path}`);
  url.searchParams.set("apiKey", apiKey);
  Object.entries(params).forEach(([key, value]) => url.searchParams.set(key, value));
  for (let attempt = 0; attempt < 3; attempt += 1) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
    try {
      const response = await fetch(url, { signal: controller.signal, headers: { Accept: "application/json" } });
      if (response.status === 429 && attempt < 2) {
        await new Promise((resolve) => setTimeout(resolve, RATE_LIMIT_RETRY_DELAY_MS * (attempt + 1)));
        continue;
      }
      if (!response.ok) throw new Error(`The Odds API responded with ${response.status}`);
      return { data: (await response.json()) as T, headers: response.headers };
    } finally {
      clearTimeout(timeout);
    }
  }
  throw new Error("The Odds API rate limit retry exhausted");
}

export async function getLiveSoccerOdds(): Promise<LiveOddsResult> {
  if (liveCache && liveCache.expiresAt > Date.now()) return liveCache.result;
  const apiKey = process.env.THE_ODDS_API_KEY;
  if (!apiKey) throw new Error("THE_ODDS_API_KEY is not configured");
  const sportsResponse = await oddsApiGet<OddsApiSport[]>("/sports", apiKey, {});
  const soccerSports = sportsResponse.data.filter((sport) => sport.active !== false && (sport.group?.toLocaleLowerCase().includes("soccer") || sport.key.startsWith("soccer_"))).filter((sport) => !/(cup|champions|europa|conference|nations|liga3|league2)$/.test(sport.key));
  const turkey = sportsResponse.data.find((sport) => sport.key === "soccer_turkey_super_league");
  if (turkey && !soccerSports.some((sport) => sport.key === turkey.key)) soccerSports.unshift(turkey);
  const now = new Date();
  const twoDays = new Date(now.getTime() + 48 * 60 * 60 * 1000);
  const allMatches: ApiMatch[] = [];
  let remaining: string | null = null;
  for (let index = 0; index < soccerSports.length; index += REQUEST_BATCH_SIZE) {
    const batch = soccerSports.slice(index, index + REQUEST_BATCH_SIZE);
    const responses = await Promise.all(batch.map((sport) => oddsApiGet<OddsApiEvent[]>(`/sports/${encodeURIComponent(sport.key)}/odds`, apiKey, { regions: "eu", markets: "h2h", oddsFormat: "decimal", dateFormat: "iso", commenceTimeFrom: oddsApiTime(now), commenceTimeTo: oddsApiTime(twoDays) })));
    responses.forEach((response) => { remaining = response.headers.get("x-requests-remaining") ?? remaining; response.data.forEach((event) => { const match = buildLiveMatch(event); if (match) allMatches.push(match); }); });
    if (index + REQUEST_BATCH_SIZE < soccerSports.length) await new Promise((resolve) => setTimeout(resolve, REQUEST_BATCH_DELAY_MS));
  }
  const uniqueMatches = Array.from(new Map(allMatches.map((match) => [match.id, match])).values()).sort((a, b) => a.time.localeCompare(b.time));
  const result = { matches: uniqueMatches, sportsCount: soccerSports.length, remaining };
  liveCache = { expiresAt: Date.now() + LIVE_CACHE_TTL_MS, result };
  return result;
}

export async function getEventMarkets(sportKey: string, eventId: string) {
  const apiKey = process.env.THE_ODDS_API_KEY;
  if (!apiKey) throw new Error("THE_ODDS_API_KEY is not configured");
  const response = await oddsApiGet<OddsApiEvent>(`/sports/${encodeURIComponent(sportKey)}/events/${encodeURIComponent(eventId)}/odds`, apiKey, { regions: "eu", markets: "totals,btts,h2h_3_way_h1,h2h_3_way_h2,totals_h1,totals_h2", oddsFormat: "decimal", dateFormat: "iso" });
  return { eventId, sportKey, markets: bestMarkets(response.data), remaining: response.headers.get("x-requests-remaining") };
}

export async function getSoccerScores(sportKeys: string[]) {
  const apiKey = process.env.THE_ODDS_API_KEY;
  if (!apiKey) throw new Error("THE_ODDS_API_KEY is not configured");
  const uniqueKeys = Array.from(new Set(sportKeys.filter(Boolean))).slice(0, 6);
  const responses = await Promise.all(uniqueKeys.map((sportKey) => oddsApiGet<OddsApiScore[]>(`/sports/${encodeURIComponent(sportKey)}/scores`, apiKey, { daysFrom: "3", dateFormat: "iso" })));
  return { scores: responses.flatMap((response) => response.data), remaining: responses.at(-1)?.headers.get("x-requests-remaining") ?? null };
}
