import { useEffect, useMemo, useState } from "react";
import {
  Activity,
  BarChart3,
  Bell,
  CalendarDays,
  Check,
  ChevronDown,
  ChevronRight,
  CircleHelp,
  Clock3,
  Database,
  Filter,
  Globe2,
  LayoutDashboard,
  ListFilter,
  Menu,
  MoreHorizontal,
  RefreshCw,
  Search,
  Settings2,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Target,
  Ticket,
  TrendingUp,
  Trophy,
  X,
  Zap,
} from "lucide-react";

type Risk = "Düşük" | "Dengeli" | "Yüksek";
type Market = "Maç Sonucu" | "Çifte Şans" | "2,5 Gol" | "Alt/Üst" | "İlk Yarı" | "İkinci Yarı" | "Karşılıklı Gol";

type EventQuote = { name: string; price: number; point?: number };
type EventMarket = { key: string; title: string; quotes: EventQuote[] };
type ScoreEvent = { id: string; sport_key: string; home_team: string; away_team: string; completed: boolean; scores?: Array<{ name: string; score: string }> | null; last_update?: string | null };
type CouponStatus = "Taslak" | "Bekliyor" | "Tuttu" | "Yattı";

type Match = {
  id: number;
  providerId?: string;
  sportKey?: string;
  country: string;
  league: string;
  level: string;
  kickoff: string;
  time: string;
  home: string;
  away: string;
  homeCode: string;
  awayCode: string;
  homeColor: string;
  awayColor: string;
  homePct: number;
  drawPct: number;
  awayPct: number;
  recommendation: string;
  market: Market;
  odds: number;
  confidence: number;
  risk: Risk;
  form: string;
  note: string;
  trend: number[];
  source?: "LIVE" | "DEMO";
  eventMarkets?: EventMarket[];
};

type Coupon = { id: string; name: string; createdAt: string; risk: Risk; picks: Match[]; status: CouponStatus };

function scoreFor(score: ScoreEvent, team: string) {
  return Number(score.scores?.find((item) => item.name === team)?.score ?? NaN);
}

function evaluatePick(match: Match, score?: ScoreEvent) {
  if (!score) return null;
  const home = scoreFor(score, match.home);
  const away = scoreFor(score, match.away);
  if (!Number.isFinite(home) || !Number.isFinite(away)) return null;
  const rec = match.recommendation.toLocaleLowerCase("tr-TR");
  if (rec.includes("2,5 alt")) return home + away < 3;
  if (rec.includes("2,5 üst")) return home + away >= 3;
  if (rec.includes(" / beraberlik")) return rec.startsWith(match.home.toLocaleLowerCase("tr-TR")) ? home >= away : away >= home;
  if (rec.includes("beraberlik")) return home === away;
  if (rec.includes(match.home.toLocaleLowerCase("tr-TR"))) return home > away;
  if (rec.includes(match.away.toLocaleLowerCase("tr-TR"))) return away > home;
  return null;
}

const matches: Match[] = [
  {
    id: 1,
    country: "İngiltere",
    league: "Premier League",
    level: "1. Lig",
    kickoff: "Bugün",
    time: "18:30",
    home: "Arsenal",
    away: "Everton",
    homeCode: "ARS",
    awayCode: "EVE",
    homeColor: "#ef5b68",
    awayColor: "#5a87da",
    homePct: 64,
    drawPct: 21,
    awayPct: 15,
    recommendation: "Arsenal kazanır",
    market: "Maç Sonucu",
    odds: 1.48,
    confidence: 91,
    risk: "Düşük",
    form: "G G G B G",
    note: "İç saha ivmesi ve son 5 maçtaki şut kalitesi öne çıkıyor.",
    trend: [48, 54, 51, 62, 69, 66, 76],
  },
  {
    id: 2,
    country: "İspanya",
    league: "La Liga",
    level: "1. Lig",
    kickoff: "Bugün",
    time: "20:00",
    home: "Real Sociedad",
    away: "Sevilla",
    homeCode: "RSO",
    awayCode: "SEV",
    homeColor: "#74a6dc",
    awayColor: "#e35a64",
    homePct: 46,
    drawPct: 29,
    awayPct: 25,
    recommendation: "Real Sociedad / Beraberlik",
    market: "Çifte Şans",
    odds: 1.32,
    confidence: 78,
    risk: "Dengeli",
    form: "B G B G M",
    note: "Düşük tempolu maç senaryosu ve ev sahibi savunması belirleyici.",
    trend: [45, 47, 43, 51, 48, 55, 54],
  },
  {
    id: 3,
    country: "İtalya",
    league: "Serie A",
    level: "1. Lig",
    kickoff: "Bugün",
    time: "21:45",
    home: "Inter",
    away: "Torino",
    homeCode: "INT",
    awayCode: "TOR",
    homeColor: "#3b73d1",
    awayColor: "#a8a2a6",
    homePct: 71,
    drawPct: 18,
    awayPct: 11,
    recommendation: "Inter kazanır",
    market: "Maç Sonucu",
    odds: 1.34,
    confidence: 94,
    risk: "Düşük",
    form: "G G G G G",
    note: "Topa sahip olma ve rakip ceza sahası aksiyonlarında net üstünlük.",
    trend: [52, 61, 65, 72, 70, 79, 86],
  },
  {
    id: 4,
    country: "Almanya",
    league: "Bundesliga",
    level: "1. Lig",
    kickoff: "Bugün",
    time: "19:30",
    home: "Leverkusen",
    away: "Mainz",
    homeCode: "B04",
    awayCode: "M05",
    homeColor: "#df3648",
    awayColor: "#e44f42",
    homePct: 68,
    drawPct: 19,
    awayPct: 13,
    recommendation: "Leverkusen kazanır",
    market: "Maç Sonucu",
    odds: 1.41,
    confidence: 89,
    risk: "Düşük",
    form: "G G B G G",
    note: "Beklenen gol farkı ve duran top üretimi modelde güçlü ağırlık taşıyor.",
    trend: [44, 51, 57, 63, 61, 74, 80],
  },
  {
    id: 5,
    country: "Fransa",
    league: "Ligue 1",
    level: "1. Lig",
    kickoff: "Yarın",
    time: "22:00",
    home: "Lille",
    away: "Monaco",
    homeCode: "LIL",
    awayCode: "ASM",
    homeColor: "#e74656",
    awayColor: "#d84d57",
    homePct: 35,
    drawPct: 27,
    awayPct: 38,
    recommendation: "2,5 Alt",
    market: "2,5 Gol",
    odds: 1.72,
    confidence: 72,
    risk: "Dengeli",
    form: "G M G B B",
    note: "İki takımın son maçlarında düşük pozisyon kalitesi ve kontrollü tempo var.",
    trend: [50, 42, 47, 45, 53, 50, 56],
  },
  {
    id: 6,
    country: "Hollanda",
    league: "Eredivisie",
    level: "1. Lig",
    kickoff: "Bugün",
    time: "17:45",
    home: "PSV",
    away: "Utrecht",
    homeCode: "PSV",
    awayCode: "UTR",
    homeColor: "#f05a55",
    awayColor: "#e9eef8",
    homePct: 73,
    drawPct: 15,
    awayPct: 12,
    recommendation: "PSV kazanır",
    market: "Maç Sonucu",
    odds: 1.27,
    confidence: 93,
    risk: "Düşük",
    form: "G G G G B",
    note: "Lig ortalamasının üzerinde hücum hacmi ve belirgin kadro sürekliliği.",
    trend: [56, 62, 64, 75, 78, 75, 88],
  },
  {
    id: 7,
    country: "İngiltere",
    league: "Championship",
    level: "2. Lig",
    kickoff: "Bugün",
    time: "21:00",
    home: "Leeds",
    away: "Norwich",
    homeCode: "LEE",
    awayCode: "NOR",
    homeColor: "#f1f3f5",
    awayColor: "#e3c54f",
    homePct: 52,
    drawPct: 25,
    awayPct: 23,
    recommendation: "Leeds kazanır",
    market: "Maç Sonucu",
    odds: 1.86,
    confidence: 75,
    risk: "Dengeli",
    form: "G B G M G",
    note: "Pres yoğunluğu ve iç saha başlangıçları Leeds lehine ayrışıyor.",
    trend: [41, 55, 52, 47, 60, 57, 65],
  },
  {
    id: 8,
    country: "İspanya",
    league: "LaLiga 2",
    level: "2. Lig",
    kickoff: "Yarın",
    time: "16:15",
    home: "Eibar",
    away: "Elche",
    homeCode: "EIB",
    awayCode: "ELC",
    homeColor: "#5d7db8",
    awayColor: "#efc04d",
    homePct: 41,
    drawPct: 33,
    awayPct: 26,
    recommendation: "Eibar / Beraberlik",
    market: "Çifte Şans",
    odds: 1.29,
    confidence: 76,
    risk: "Dengeli",
    form: "B B G G M",
    note: "Beraberlik olasılığı yüksek; iki takımın üretim farkı sınırlı.",
    trend: [43, 45, 48, 52, 49, 54, 50],
  },
  {
    id: 9,
    country: "Almanya",
    league: "2. Bundesliga",
    level: "2. Lig",
    kickoff: "Bugün",
    time: "20:30",
    home: "Hamburg",
    away: "Hertha",
    homeCode: "HSV",
    awayCode: "BSC",
    homeColor: "#5e9cce",
    awayColor: "#78a9d4",
    homePct: 43,
    drawPct: 24,
    awayPct: 33,
    recommendation: "2,5 Üst",
    market: "2,5 Gol",
    odds: 1.64,
    confidence: 69,
    risk: "Yüksek",
    form: "M G G M G",
    note: "Geçiş hücumları ve iki takımın son 6 maç gol ortalaması yukarı sinyal veriyor.",
    trend: [38, 48, 44, 61, 58, 66, 63],
  },
  {
    id: 10,
    country: "İtalya",
    league: "Serie B",
    level: "2. Lig",
    kickoff: "Yarın",
    time: "18:00",
    home: "Palermo",
    away: "Bari",
    homeCode: "PAL",
    awayCode: "BAR",
    homeColor: "#df7182",
    awayColor: "#db323e",
    homePct: 49,
    drawPct: 31,
    awayPct: 20,
    recommendation: "Palermo / Beraberlik",
    market: "Çifte Şans",
    odds: 1.31,
    confidence: 80,
    risk: "Düşük",
    form: "G B G B G",
    note: "Ev sahibi savunma dengesi ve rakibin deplasman üretim düşüşü etkili.",
    trend: [46, 49, 55, 52, 61, 59, 69],
  },
  {
    id: 11,
    country: "Brezilya",
    league: "Brasileirão",
    level: "1. Lig",
    kickoff: "Yarın",
    time: "01:00",
    home: "Flamengo",
    away: "Gremio",
    homeCode: "FLA",
    awayCode: "GRE",
    homeColor: "#ed384b",
    awayColor: "#5e86c9",
    homePct: 57,
    drawPct: 24,
    awayPct: 19,
    recommendation: "Flamengo kazanır",
    market: "Maç Sonucu",
    odds: 1.67,
    confidence: 82,
    risk: "Dengeli",
    form: "G G M G B",
    note: "Ev sahibi geçiş savunmasında gelişti; rakibin dış saha şut hacmi düşük.",
    trend: [40, 51, 49, 58, 62, 68, 64],
  },
  {
    id: 12,
    country: "Fransa",
    league: "Ligue 2",
    level: "2. Lig",
    kickoff: "Yarın",
    time: "20:00",
    home: "Metz",
    away: "Caen",
    homeCode: "MET",
    awayCode: "CAE",
    homeColor: "#e64c60",
    awayColor: "#375fb8",
    homePct: 45,
    drawPct: 30,
    awayPct: 25,
    recommendation: "2,5 Alt",
    market: "2,5 Gol",
    odds: 1.58,
    confidence: 74,
    risk: "Dengeli",
    form: "B G B M G",
    note: "Son 10 karşılaşmanın 7'si 2,5 gol çizgisinin altında kaldı.",
    trend: [49, 46, 51, 48, 54, 52, 58],
  },
  {
    id: 13,
    country: "Türkiye",
    league: "Süper Lig",
    level: "1. Lig",
    kickoff: "Yarın",
    time: "19:00",
    home: "Beşiktaş",
    away: "Trabzonspor",
    homeCode: "BJK",
    awayCode: "TS",
    homeColor: "#111827",
    awayColor: "#7e2635",
    homePct: 44,
    drawPct: 28,
    awayPct: 28,
    recommendation: "Beşiktaş / Beraberlik",
    market: "Çifte Şans",
    odds: 1.38,
    confidence: 77,
    risk: "Dengeli",
    form: "G B G M B",
    note: "Türkiye Süper Lig filtresini ve analiz akışını göstermek için kullanılan demo fallback. Canlı API verisi geldiğinde bu satır gerçek fikstürle değişir.",
    trend: [45, 48, 51, 47, 55, 52, 62],
  },
];

const countryOptions = ["Tüm ülkeler", ...Array.from(new Set(matches.map((match) => match.country)))];
const leagueOptions = ["Tüm ligler", "Süper Lig", "Premier League", "La Liga", "Serie A", "Bundesliga", "Ligue 1", "Eredivisie", "Championship", "LaLiga 2", "2. Bundesliga", "Serie B", "Brasileirão", "Ligue 2"];
const marketOptions: Array<"Tüm marketler" | Market> = ["Tüm marketler", "Maç Sonucu", "Çifte Şans", "2,5 Gol", "Alt/Üst", "İlk Yarı", "İkinci Yarı", "Karşılıklı Gol"];
const riskOptions: Array<"Tüm riskler" | Risk> = ["Tüm riskler", "Düşük", "Dengeli", "Yüksek"];

function TeamBadge({ code, color }: { code: string; color: string }) {
  return (
    <span className="team-badge" style={{ background: color }}>
      {code.slice(0, 3)}
    </span>
  );
}

function ProbabilityBar({ value, color }: { value: number; color: string }) {
  return (
    <div className="probability-track">
      <span style={{ width: `${value}%`, background: color }} />
    </div>
  );
}

function Sparkline({ values }: { values: number[] }) {
  const max = Math.max(...values);
  const min = Math.min(...values);
  const points = values
    .map((value, index) => {
      const x = (index / (values.length - 1)) * 100;
      const y = 30 - ((value - min) / Math.max(1, max - min)) * 24;
      return `${x},${y}`;
    })
    .join(" ");

  return (
    <svg viewBox="0 0 100 34" className="sparkline" preserveAspectRatio="none" aria-label="Form trendi">
      <polyline points={points} fill="none" stroke="currentColor" strokeWidth="2.2" vectorEffect="non-scaling-stroke" />
    </svg>
  );
}

function RiskPill({ risk }: { risk: Risk }) {
  return <span className={`risk-pill ${risk === "Düşük" ? "low" : risk === "Yüksek" ? "high" : "medium"}`}>{risk}</span>;
}

function StatCard({ label, value, detail, icon: Icon, accent }: { label: string; value: string; detail: string; icon: typeof Activity; accent: string }) {
  return (
    <div className="stat-card">
      <div className="stat-topline">
        <span className="eyebrow">{label}</span>
        <span className="stat-icon" style={{ color: accent, background: `${accent}16` }}><Icon size={16} /></span>
      </div>
      <div className="stat-value">{value}</div>
      <div className="stat-detail"><span className="positive-dot" style={{ background: accent }} />{detail}</div>
    </div>
  );
}

export default function Home() {
  const [league, setLeague] = useState("Tüm ligler");
  const [country, setCountry] = useState("Tüm ülkeler");
  const [market, setMarket] = useState<(typeof marketOptions)[number]>("Tüm marketler");
  const [risk, setRisk] = useState<(typeof riskOptions)[number]>("Tüm riskler");
  const [modelRisk, setModelRisk] = useState<Risk>("Dengeli");
  const [date, setDate] = useState("Bugün + yarın");
  const [query, setQuery] = useState("");
  const [couponCount, setCouponCount] = useState(5);
  const [selectedIds, setSelectedIds] = useState<number[]>([1, 3, 6]);
  const [activeNav, setActiveNav] = useState("Genel Bakış");
  const [detailsId, setDetailsId] = useState<number | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const [generatedAt, setGeneratedAt] = useState("09:42");
  const [reviewOpen, setReviewOpen] = useState(false);
  const [couponVariant, setCouponVariant] = useState(0);
  const [availableMatches, setAvailableMatches] = useState(matches);
  const [dataStatus, setDataStatus] = useState<"LIVE" | "DEMO" | "LOADING">("LOADING");
  const [sportsCount, setSportsCount] = useState(0);
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [scoreEvents, setScoreEvents] = useState<ScoreEvent[]>([]);
  const [scoreNotice, setScoreNotice] = useState<string>("");
  const [eventMarkets, setEventMarkets] = useState<EventMarket[]>([]);
  const [eventMarketsLoading, setEventMarketsLoading] = useState(false);

  useEffect(() => {
    let active = true;
    fetch("/api/odds/soccer")
      .then(async (response) => {
        if (!response.ok) throw new Error("live odds unavailable");
        return response.json() as Promise<{ matches?: Match[]; sportsCount?: number }>;
      })
      .then((payload) => {
        if (!active) return;
        if (payload.matches?.length) {
          setAvailableMatches(payload.matches);
          setSelectedIds([]);
          setSportsCount(payload.sportsCount ?? 0);
          setDataStatus("LIVE");
          setGeneratedAt(new Date().toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" }));
        } else {
          setDataStatus("DEMO");
        }
      })
      .catch(() => {
        if (active) setDataStatus("DEMO");
      });
    return () => { active = false; };
  }, []);

  useEffect(() => {
    const detail = detailsId ? availableMatches.find((match) => match.id === detailsId) : null;
    if (!detail?.providerId || !detail.sportKey) {
      setEventMarkets([]);
      return;
    }
    let active = true;
    setEventMarketsLoading(true);
    fetch(`/api/odds/event?sportKey=${encodeURIComponent(detail.sportKey)}&eventId=${encodeURIComponent(detail.providerId)}`)
      .then((response) => response.json())
      .then((payload: { markets?: EventMarket[] }) => { if (active) setEventMarkets(payload.markets ?? []); })
      .catch(() => { if (active) setEventMarkets([]); })
      .finally(() => { if (active) setEventMarketsLoading(false); });
    return () => { active = false; };
  }, [detailsId, availableMatches]);

  useEffect(() => {
    const sportKeys = Array.from(new Set(availableMatches.map((match) => match.sportKey).filter(Boolean) as string[])).slice(0, 5);
    if (!sportKeys.length) return;
    let active = true;
    const loadScores = () => fetch(`/api/odds/scores?sports=${encodeURIComponent(sportKeys.join(","))}`)
      .then((response) => response.json())
      .then((payload: { scores?: ScoreEvent[] }) => {
        if (!active) return;
        const nextScores = payload.scores ?? [];
        setScoreEvents(nextScores);
        const liveCount = nextScores.filter((item) => !item.completed && item.scores?.length).length;
        setScoreNotice(liveCount ? `${liveCount} canlı maçta skor takibi açık` : "Canlı gol bildirimi için skor akışı hazır");
      })
      .catch(() => { if (active) setScoreNotice("Canlı skor servisi şu anda yanıt vermiyor"); });
    loadScores();
    const timer = window.setInterval(loadScores, 60_000);
    return () => { active = false; window.clearInterval(timer); };
  }, [availableMatches]);

  const filteredMatches = useMemo(() => {
    const normalizedQuery = query.trim().toLocaleLowerCase("tr-TR");
    return availableMatches.filter((match) => {
      const textMatch = !normalizedQuery || `${match.home} ${match.away} ${match.league} ${match.country}`.toLocaleLowerCase("tr-TR").includes(normalizedQuery);
      const countryMatch = country === "Tüm ülkeler" || match.country === country;
      const leagueMatch = league === "Tüm ligler" || match.league === league;
      const marketMatch = market === "Tüm marketler" || match.market === market;
      const riskMatch = risk === "Tüm riskler" || match.risk === risk;
      const dateMatch = date === "Bugün + yarın" || match.kickoff === date;
      return textMatch && countryMatch && leagueMatch && marketMatch && riskMatch && dateMatch;
    });
  }, [availableMatches, country, date, league, market, query, risk]);

  const selectedMatches = useMemo(() => availableMatches.filter((match) => selectedIds.includes(match.id)), [availableMatches, selectedIds]);
  const detailsMatch = detailsId ? availableMatches.find((match) => match.id === detailsId) : null;
  const averageConfidence = Math.round(selectedMatches.reduce((total, match) => total + match.confidence, 0) / Math.max(1, selectedMatches.length));
  const totalOdds = selectedMatches.reduce((total, match) => total * match.odds, 1);
  const expectedHit = Math.round(selectedMatches.reduce((total, match) => total + Math.max(match.homePct, match.drawPct, match.awayPct), 0) / Math.max(1, selectedMatches.length));
  const activeCountryOptions = useMemo(() => ["Tüm ülkeler", ...Array.from(new Set(availableMatches.map((match) => match.country)))], [availableMatches]);
  const activeLeagueOptions = useMemo(() => ["Tüm ligler", ...Array.from(new Set(availableMatches.map((match) => match.league)))], [availableMatches]);
  const leagueSummary = useMemo(() => Array.from(new Map(availableMatches.map((match) => [match.league, match])).values()).slice(0, 18), [availableMatches]);
  const scoreByProviderId = useMemo(() => new Map(scoreEvents.map((score) => [score.id, score])), [scoreEvents]);
  const visibleCoupons = useMemo(() => coupons.map((coupon) => {
    const results = coupon.picks.map((pick) => pick.providerId ? evaluatePick(pick, scoreByProviderId.get(pick.providerId)) : null);
    const status: CouponStatus = results.every((result) => result === true) && results.length > 0 ? "Tuttu" : results.some((result) => result === false) ? "Yattı" : results.some((result) => result === true) ? "Bekliyor" : coupon.status;
    return { ...coupon, status };
  }), [coupons, scoreByProviderId]);

  const toggleMatch = (id: number) => {
    setSelectedIds((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id]);
  };

  const generateCoupon = (riskOverride?: Risk) => {
    const target = Math.max(1, Number(couponCount) || 1);
    const selectedProfile = riskOverride ?? modelRisk;
    const riskBoost = (match: Match) => {
      if (selectedProfile === "Düşük") return match.risk === "Düşük" ? 24 : match.risk === "Dengeli" ? 7 : -12;
      if (selectedProfile === "Yüksek") return match.risk === "Yüksek" ? 24 : match.risk === "Dengeli" ? 10 : -4;
      return match.risk === "Dengeli" ? 14 : 7;
    };
    const ranked = [...filteredMatches].sort((a, b) => (b.confidence + Math.max(b.homePct, b.drawPct, b.awayPct) / 2 + riskBoost(b)) - (a.confidence + Math.max(a.homePct, a.drawPct, a.awayPct) / 2 + riskBoost(a)));
    const offset = ranked.length ? (couponVariant * Math.max(1, target)) % ranked.length : 0;
    const picks = ranked.length <= target ? ranked : Array.from({ length: target }, (_, index) => ranked[(offset + index) % ranked.length]);
    setSelectedIds(picks.map((match) => match.id));
    setCoupons((current) => [{ id: `${Date.now()}-${couponVariant}`, name: `${selectedProfile} profil kuponu`, createdAt: new Date().toLocaleString("tr-TR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" }), risk: selectedProfile, picks, status: "Taslak" as CouponStatus }, ...current].slice(0, 20));
    setCouponVariant((value) => value + 1);
    setGeneratedAt(new Date().toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" }));
  };

  const resetFilters = () => {
    setLeague("Tüm ligler");
    setCountry("Tüm ülkeler");
    setMarket("Tüm marketler");
    setRisk("Tüm riskler");
    setDate("Bugün + yarın");
    setQuery("");
  };

  return (
    <div className="app-shell">
      <aside className={`sidebar ${menuOpen ? "open" : ""}`}>
        <div className="brand-lockup">
          <div className="brand-mark"><span /><span /></div>
          <div>
            <div className="brand-name">oranix</div>
            <div className="brand-caption">GLOBAL MAÇ ANALİZİ</div>
          </div>
        </div>
        <div className="sidebar-section-label">ÇALIŞMA ALANI</div>
        <nav className="side-nav">
          {[
            { label: "Genel Bakış", icon: LayoutDashboard },
            { label: "Kuponlarım", icon: Ticket },
            { label: "Lig Merkezi", icon: Globe2 },
            { label: "Tahmin Geçmişi", icon: BarChart3 },
          ].map(({ label, icon: Icon }) => (
            <button key={label} className={`side-nav-item ${activeNav === label ? "active" : ""}`} onClick={() => { setActiveNav(label); setMenuOpen(false); }}>
              <Icon size={17} />
              <span>{label}</span>
              {label === "Kuponlarım" && selectedIds.length > 0 && <b>{selectedIds.length}</b>}
            </button>
          ))}
        </nav>
        <div className="sidebar-section-label source-label">VERİ KAYNAĞI</div>
        <div className="data-status-card">
          <span className="status-orb"><Database size={14} /></span>
          <div><strong>{dataStatus === "LIVE" ? "Canlı veri akışı" : dataStatus === "LOADING" ? "Veri yükleniyor" : "Demo veri akışı"}</strong><span>{dataStatus === "LIVE" ? `${sportsCount} futbol ligi tarandı` : "The Odds API bağlantısı"}</span></div>
          <span className="live-dot" />
        </div>
        <div className="sidebar-bottom">
          <button className="side-nav-item"><Settings2 size={17} /><span>Ayarlar</span></button>
          <button className="side-nav-item"><CircleHelp size={17} /><span>Nasıl çalışır?</span></button>
          <div className="profile-card">
            <div className="profile-avatar">AK</div>
            <div><strong>Analiz masası</strong><span>Standart görünüm</span></div>
            <MoreHorizontal size={16} className="profile-more" />
          </div>
        </div>
      </aside>

      <main className="main-content">
        <header className="topbar">
          <div className="topbar-left">
            <button className="mobile-menu" onClick={() => setMenuOpen((value) => !value)}><Menu size={20} /></button>
            <div>
              <div className="breadcrumb"><span>Oranix</span><ChevronRight size={13} /><strong>{activeNav}</strong></div>
              <h1>{activeNav === "Genel Bakış" ? "Bugünün sinyallerini gürültüden ayır." : activeNav}</h1>
            </div>
          </div>
          <div className="topbar-actions">
            <div className="data-refresh"><span className="live-dot" /> Son tarama <strong>{generatedAt}</strong></div>
            <button className="icon-button" aria-label="Bildirimler"><Bell size={18} /><i /></button>
            <button className="avatar-button">AK</button>
          </div>
        </header>

        {activeNav === "Genel Bakış" ? <div className="content-grid">
          <section className="workspace">
            <div className="page-intro">
              <div>
                <span className="section-kicker"><span className="kicker-line" /> MAÇ PANOSU / 10 EKİM 2026</span>
                <p>Bugün ve yarının karşılaşmaları, model güvenine göre sıralandı.</p>
                <div className={`source-banner ${dataStatus.toLowerCase()}`}><span className="live-dot" /> {dataStatus === "LIVE" ? `Canlı The Odds API · ${sportsCount} futbol ligi tarandı` : dataStatus === "LOADING" ? "Canlı veri yükleniyor…" : "Demo veri · canlı bağlantı yeniden denenebilir"}</div>
                {scoreNotice && <div className="score-banner"><span className="live-dot" /> <strong>CANLI SKOR</strong><span>{scoreNotice}</span>{scoreEvents.filter((score) => !score.completed && score.scores?.length).slice(0, 3).map((score) => <b key={score.id}>{score.home_team} {scoreFor(score, score.home_team)}–{scoreFor(score, score.away_team)} {score.away_team}</b>)}</div>}
              </div>
              <button className="refresh-button" onClick={() => window.location.reload()}><RefreshCw size={15} /> Yenile</button>
            </div>

            <div className="stats-row">
              <StatCard label="İNCELENEN MAÇ" value={`${filteredMatches.length}`} detail="12 ligde analiz hazır" icon={Trophy} accent="#c9f27a" />
              <StatCard label="ORT. MODEL GÜVENİ" value="81.4%" detail="Son 7 güne göre +3.2" icon={Target} accent="#9edbff" />
              <StatCard label="DEĞER SİNYALİ" value="8" detail="Oranın üzerinde olasılık" icon={TrendingUp} accent="#d9a5ff" />
              <StatCard label="VERİ TAZELİĞİ" value="14 dk" detail="Son güncelleme bekleniyor" icon={Activity} accent="#ffc66e" />
            </div>

            <div className="filter-bar">
              <div className="filter-search"><Search size={16} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Takım, lig veya ülke ara" /></div>
              <div className="select-wrap"><CalendarDays size={15} /><select value={date} onChange={(event) => setDate(event.target.value)}><option>Bugün + yarın</option><option>Bugün</option><option>Yarın</option></select><ChevronDown size={14} /></div>
              <div className="select-wrap"><Globe2 size={15} /><select value={country} onChange={(event) => setCountry(event.target.value)}>{activeCountryOptions.map((item) => <option key={item}>{item}</option>)}</select><ChevronDown size={14} /></div>
              <div className="select-wrap"><Globe2 size={15} /><select value={league} onChange={(event) => setLeague(event.target.value)}>{activeLeagueOptions.map((item) => <option key={item}>{item}</option>)}</select><ChevronDown size={14} /></div>
              <div className="select-wrap"><ListFilter size={15} /><select value={market} onChange={(event) => setMarket(event.target.value as typeof market)}>{marketOptions.map((item) => <option key={item}>{item}</option>)}</select><ChevronDown size={14} /></div>
              <div className="select-wrap"><SlidersHorizontal size={15} /><select value={risk} onChange={(event) => setRisk(event.target.value as typeof risk)}>{riskOptions.map((item) => <option key={item}>{item}</option>)}</select><ChevronDown size={14} /></div>
              <button className="filter-reset" onClick={resetFilters}><Filter size={15} /> Sıfırla</button>
            </div>

            <div className="board-head">
              <div><span className="eyebrow">MAÇ AKIŞI</span><strong>{filteredMatches.length} karşılaşma</strong></div>
              <div className="board-legend"><span><i className="legend-dot mint" /> Güçlü sinyal</span><span><i className="legend-dot amber" /> İnceleme önerilir</span></div>
            </div>

            <div className="match-list">
              {filteredMatches.length === 0 ? (
                <div className="empty-state"><Search size={22} /><strong>Bu filtrelerde maç bulunamadı</strong><span>Filtreleri gevşeterek tekrar deneyebilirsin.</span><button onClick={resetFilters}>Filtreleri temizle</button></div>
              ) : filteredMatches.map((match) => {
                const selected = selectedIds.includes(match.id);
                const topPct = Math.max(match.homePct, match.drawPct, match.awayPct);
                return (
                  <article className={`match-row ${selected ? "selected" : ""}`} key={match.id}>
                    <div className="match-time"><span>{match.kickoff}</span><strong>{match.time}</strong><small>{match.country}</small></div>
                    <div className="match-teams">
                      <div className="league-line"><span>{match.league}</span><em>{match.level}</em><em className="demo-tag">{match.source ?? "DEMO"}</em></div>
                      <div className="team-line"><TeamBadge code={match.homeCode} color={match.homeColor} /><strong>{match.home}</strong></div>
                      <div className="team-line"><TeamBadge code={match.awayCode} color={match.awayColor} /><strong>{match.away}</strong></div>
                    </div>
                    <div className="probability-block">
                      <div className="probability-head"><span>MODEL OLASILIĞI</span><span className="top-prob">{topPct}% <small>en güçlü</small></span></div>
                      <div className="probability-grid"><div><span>1</span><b>{match.homePct}%</b><ProbabilityBar value={match.homePct} color="#9edbff" /></div><div><span>X</span><b>{match.drawPct}%</b><ProbabilityBar value={match.drawPct} color="#9ca9bd" /></div><div><span>2</span><b>{match.awayPct}%</b><ProbabilityBar value={match.awayPct} color="#d9a5ff" /></div></div>
                    </div>
                    <div className="recommendation"><span className="eyebrow">ÖNERİ</span><strong>{match.recommendation}</strong><span className="odds">Oran <b>{match.odds.toFixed(2)}</b></span></div>
                    <div className="confidence-cell"><span className={`confidence-ring ${match.confidence >= 85 ? "strong" : match.confidence >= 75 ? "steady" : "watch"}`}><b>{match.confidence}</b></span><span>güven</span></div>
                    <div className="row-actions"><RiskPill risk={match.risk} /><button className={`select-match ${selected ? "checked" : ""}`} onClick={() => toggleMatch(match.id)} aria-label={`${match.home} ${match.away} seç`}><Check size={15} /></button><button className="detail-button" onClick={() => setDetailsId(match.id)}>Detay <ChevronRight size={14} /></button></div>
                  </article>
                );
              })}
            </div>
            <div className="data-disclaimer"><ShieldCheck size={15} /><span>Model sonuçları geçmiş performans, form, kadro ve oran sinyallerinden üretilen istatistiksel tahminlerdir; <strong>garanti değildir.</strong></span></div>
          </section>

          <aside className="coupon-panel">
            <div className="coupon-header"><div><span className="section-kicker"><span className="kicker-line" /> KUPON ÇALIŞMA YÜZÜ</span><h2>Kuponunu kur.</h2></div><button className="panel-more"><MoreHorizontal size={18} /></button></div>
            <div className="coupon-intro"><Sparkles size={16} /><span>Model, seçtiğin kriterlere göre en güçlü sinyalleri sıralar. Son karar senin.</span></div>
            <div className="coupon-control">
              <div><span className="eyebrow">KAÇ MAÇ OLSUN?</span><strong>Kupon uzunluğu</strong><small>Filtredeki {filteredMatches.length} maça kadar seçebilirsin.</small>{couponCount > filteredMatches.length && <small className="count-warning">Bu filtrede {filteredMatches.length} maç var; model bulunanların tamamını seçer.</small>}</div>
              <div className="number-stepper"><button onClick={() => setCouponCount((value) => Math.max(1, value - 1))}>−</button><input type="number" min={1} value={couponCount} onChange={(event) => setCouponCount(Math.max(1, Number(event.target.value) || 1))} /><button onClick={() => setCouponCount((value) => value + 1)}>+</button></div>
            </div>
            <div className="risk-selector"><span className="eyebrow">MODEL TERCİHİ</span><div className="segmented-control"><button className={modelRisk === "Düşük" ? "active" : ""} onClick={() => setModelRisk("Düşük")}>Koruma</button><button className={modelRisk === "Dengeli" ? "active" : ""} onClick={() => setModelRisk("Dengeli")}>Dengeli</button><button className={modelRisk === "Yüksek" ? "active" : ""} onClick={() => setModelRisk("Yüksek")}>Değer</button></div></div>
            <button className="generate-button" onClick={() => generateCoupon()}><Zap size={16} /> {couponCount} maçlık kupon oluştur <ChevronRight size={16} /></button>
            <div className="coupon-summary"><div><span className="eyebrow">SEÇİLİ KUPON</span><strong>{selectedMatches.length} maç seçildi</strong></div><span className="coupon-state">{selectedMatches.length > 0 ? "Taslak" : "Boş"}</span></div>
            <div className="coupon-picks">
              {selectedMatches.length === 0 ? <div className="coupon-empty"><Ticket size={25} /><span>Maç panosundan seçim yap veya modelin senin için kupon oluşturmasına izin ver.</span></div> : selectedMatches.map((match, index) => (
                <div className="coupon-pick" key={match.id}><div className="pick-index">{String(index + 1).padStart(2, "0")}</div><div className="pick-main"><div><strong>{match.home}</strong><span> – </span><strong>{match.away}</strong></div><small>{match.league} · {match.recommendation}</small></div><div className="pick-odds"><span>{match.odds.toFixed(2)}</span><button onClick={() => toggleMatch(match.id)} aria-label="Seçimi kaldır"><X size={14} /></button></div></div>
              ))}
            </div>
            <div className="coupon-footer"><div><span>Tahmini toplam oran</span><strong>{selectedMatches.length ? totalOdds.toFixed(2) : "—"}</strong></div><div><span>Ortalama güven</span><strong>{selectedMatches.length ? `${averageConfidence}%` : "—"}</strong></div><div><span>En güçlü tahmin ort.</span><strong>{selectedMatches.length ? `${expectedHit}%` : "—"}</strong></div></div>
            <button className="review-button" disabled={!selectedMatches.length} onClick={() => setReviewOpen(true)}><Check size={15} /> Kuponu incelemeye al</button>
            <div className="responsible-note"><ShieldCheck size={14} /><span>Bu kupon yalnızca analiz ve önizleme içindir. Otomatik bahis, ödeme veya para yatırma yapılmaz.</span></div>
          </aside>
        </div> : <section className="secondary-view">
          <div className="secondary-heading"><span className="section-kicker"><span className="kicker-line" /> ORANIX / {activeNav.toUpperCase()}</span><h2>{activeNav === "Kuponlarım" ? "Taslaklarını tek yerde incele." : activeNav === "Lig Merkezi" ? "Dünya liglerini karşılaştır." : "Modelin geçmiş sinyallerini izle."}</h2><p>{activeNav === "Kuponlarım" ? "Seçtiğin maçları kontrol et, farklı bir kombinasyon üret veya inceleme ekranını aç." : activeNav === "Lig Merkezi" ? "The Odds API’nin aktif tuttuğu üst ve ikinci seviye liglerdeki yaklaşan maçlar." : "Bu görünüm gerçek sonuç iddiası değil, son model taramalarının izidir."}</p></div>
          {activeNav === "Kuponlarım" && <div className="secondary-card coupon-library"><div className="secondary-card-head"><div><span className="eyebrow">AKTİF TASLAK</span><h3>{selectedMatches.length} maçlık kupon</h3></div><div className="coupon-actions"><button className="generate-button compact" onClick={() => generateCoupon()}><Zap size={15} /> Farklı kupon üret</button><button className="risk-coupon-button" onClick={() => generateCoupon("Yüksek")}>Riskli kupon</button></div></div>{selectedMatches.length === 0 ? <div className="secondary-empty"><Ticket size={23} /><span>Henüz maç seçilmedi. Genel Bakış sekmesine dönüp seçim yapabilir veya model kuponu oluşturabilirsin.</span><button onClick={() => setActiveNav("Genel Bakış")}>Maç panosuna git</button></div> : <div className="secondary-picks">{selectedMatches.map((match, index) => <div className="secondary-pick" key={match.id}><span>{String(index + 1).padStart(2, "0")}</span><div><strong>{match.home} – {match.away}</strong><small>{match.league} · {match.recommendation}</small></div><b>{match.odds.toFixed(2)}</b><button onClick={() => toggleMatch(match.id)}><X size={14} /></button></div>)}</div>}<div className="secondary-footer"><span>Toplam oran <b>{selectedMatches.length ? totalOdds.toFixed(2) : "—"}</b></span><span>Ortalama güven <b>{selectedMatches.length ? `${averageConfidence}%` : "—"}</b></span><button className="review-button" disabled={!selectedMatches.length} onClick={() => setReviewOpen(true)}><Check size={14} /> İncelemeye al</button></div><div className="coupon-history"><span className="eyebrow">AYRI KUPONLAR</span>{visibleCoupons.length === 0 ? <small>Ürettiğin kuponlar burada ayrı ayrı saklanır.</small> : visibleCoupons.map((coupon) => <button key={coupon.id} className="coupon-history-row" onClick={() => setSelectedIds(coupon.picks.map((pick) => pick.id))}><span><strong>{coupon.name}</strong><small>{coupon.createdAt} · {coupon.picks.length} maç</small></span><RiskPill risk={coupon.risk} /><b className={`coupon-result ${coupon.status.toLocaleLowerCase("tr-TR")}`}>{coupon.status}</b></button>)}</div></div>}
          {activeNav === "Lig Merkezi" && <div className="league-grid">{leagueSummary.map((match) => <button className="league-card" key={match.league} onClick={() => { setLeague(match.league); setActiveNav("Genel Bakış"); }}><div><span className="eyebrow">{match.country}</span><h3>{match.league}</h3><small>{availableMatches.filter((item) => item.league === match.league).length} yaklaşan maç · {match.level}</small></div><ChevronRight size={17} /></button>)}</div>}
          {activeNav === "Tahmin Geçmişi" && <div className="secondary-card history-card"><div className="secondary-card-head"><div><span className="eyebrow">SON TARAMALAR</span><h3>Model sinyal geçmişi</h3></div><span className="coupon-state">İstatistiksel</span></div><div className="history-list">{availableMatches.slice(0, 12).map((match) => <div className="history-row" key={match.id}><span className="history-date">{match.kickoff}<small>{match.time}</small></span><div><strong>{match.home} – {match.away}</strong><small>{match.recommendation} · {match.source ?? "DEMO"}</small></div><span className="history-confidence">{match.confidence}%</span><RiskPill risk={match.risk} /></div>)}</div></div>}
        </section>}
      </main>

      {detailsMatch && <div className="modal-backdrop" onClick={() => setDetailsId(null)}><div className="match-modal" onClick={(event) => event.stopPropagation()}><button className="modal-close" onClick={() => setDetailsId(null)}><X size={18} /></button><div className="modal-kicker"><span className="live-dot" /> MAÇ ANALİZİ · {detailsMatch.source === "LIVE" ? "CANLI VERİ" : "DEMO VERİ"}</div><div className="modal-match-title"><div><TeamBadge code={detailsMatch.homeCode} color={detailsMatch.homeColor} /><strong>{detailsMatch.home}</strong></div><span>{detailsMatch.time}<small>{detailsMatch.country}</small></span><div><TeamBadge code={detailsMatch.awayCode} color={detailsMatch.awayColor} /><strong>{detailsMatch.away}</strong></div></div><div className="modal-grid"><div className="modal-stat"><span>MODELİN ÖNERİSİ</span><strong>{detailsMatch.recommendation}</strong><small>Mevcut market: {detailsMatch.market}</small></div><div className="modal-stat"><span>GÜVEN SKORU</span><strong>{detailsMatch.confidence}%</strong><small><RiskPill risk={detailsMatch.risk} /></small></div><div className="modal-stat"><span>TAHMİNİ ORAN</span><strong>{detailsMatch.odds.toFixed(2)}</strong><small>{detailsMatch.source === "LIVE" ? "The Odds API h2h" : "Demo akış"}</small></div></div><div className="event-markets"><div className="analysis-title"><BarChart3 size={16} /> Alt/üst ve devre marketleri</div>{eventMarketsLoading ? <span className="market-loading">Marketler yükleniyor…</span> : eventMarkets.length ? <div className="market-grid">{eventMarkets.map((eventMarket) => <div className="event-market" key={eventMarket.key}><strong>{eventMarket.title}</strong>{eventMarket.quotes.slice(0, 6).map((quote, index) => <span key={`${eventMarket.key}-${index}`}>{quote.name}{quote.point !== undefined ? ` ${quote.point}` : ""}<b>{quote.price.toFixed(2)}</b></span>)}</div>)}</div> : <span className="market-loading">Bu karşılaşma için alt/üst veya devre marketi sağlayıcıda açık değil; sahte oran gösterilmiyor.</span>}</div><div className="modal-analysis"><div><div className="analysis-title"><BarChart3 size={16} /> Model notu</div><p>{detailsMatch.note}</p></div><div className="modal-trend"><span className="eyebrow">FORM TRENDİ</span><Sparkline values={detailsMatch.trend} /></div></div><button className="modal-select" onClick={() => { toggleMatch(detailsMatch.id); setDetailsId(null); }}><Check size={16} /> {selectedIds.includes(detailsMatch.id) ? "Kupondan çıkar" : "Kupona ekle"}</button></div></div>}
      {reviewOpen && <div className="modal-backdrop" onClick={() => setReviewOpen(false)}><div className="match-modal review-modal" onClick={(event) => event.stopPropagation()}><button className="modal-close" onClick={() => setReviewOpen(false)}><X size={18} /></button><div className="modal-kicker"><span className="live-dot" /> TASLAK İNCELEME · GERÇEK BAHİS YOK</div><h2>Kuponunu kontrol et.</h2><p className="review-lead">Bu ekran yalnızca seçtiğin analizleri gözden geçirmen içindir. Kupon herhangi bir bahis hesabına gönderilmez.</p><div className="review-list">{selectedMatches.map((match, index) => <div className="review-line" key={match.id}><span>{String(index + 1).padStart(2, "0")}</span><div><strong>{match.home} – {match.away}</strong><small>{match.recommendation} · {match.league}</small></div><b>{match.odds.toFixed(2)}</b></div>)}</div><div className="review-total"><span>Toplam oran <strong>{totalOdds.toFixed(2)}</strong></span><span>Ortalama güven <strong>{averageConfidence}%</strong></span></div><button className="modal-select" onClick={() => setReviewOpen(false)}><Check size={16} /> Taslağı kapat</button></div></div>}
    </div>
  );
}
