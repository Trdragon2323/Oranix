# The Odds API entegrasyon notları

Kaynaklar:
- https://the-odds-api.com/sports-odds-data/betting-markets.html
- https://the-odds-api.com/liveapi/guides/v4/

Doğrulanan V4 uçları ve marketler:
- Event odds: `/v4/sports/{sport}/events/{eventId}/odds`
- Scores: `/v4/sports/{sport}/scores?daysFrom=3&dateFormat=iso`
- Featured marketler: `h2h`, `totals` (alt/üst), `btts`
- Devre marketleri: `h2h_3_way_h1`, `h2h_3_way_h2`, `totals_h1`, `totals_h2`
- Skor endpoint’i canlı ve yakın zamanda tamamlanan maçları döndürür; canlı skorlar yaklaşık 30 saniyede güncellenir.
- Event bazlı market sorguları sağlayıcının desteklediği marketleri döndürür; her lig/kitapçıda tüm marketlerin bulunması garanti değildir. Uygulama veri yoksa sahte oran üretmemelidir.
- `/sports` yanıtında doğrulanan Türkiye anahtarı: `soccer_turkey_super_league` — `Turkey Super League`, active=true.
