# Oranix — Global Maç Analizi

## Ürün kapsamı

Oranix, dünya genelindeki veri sağlayıcısının desteklediği en üst seviye ve 2. seviye futbol liglerini tek panelde inceleyen Türkçe bir analiz uygulamasıdır. İlk çalışan sürüm, gerçek bahis oynatmadan maç analizlerini, yüzdesel olasılıkları, güven skorlarını ve kullanıcı kontrollü otomatik kupon önerisini görünür kılar. Harici canlı veri sağlayıcısı bağlanana kadar arayüz, açıkça “demo veri” etiketli örnek maç veri setiyle çalışır.

Gereksinimler:

- Dünya genelinde 1. ve 2. seviye ligleri ülke/lig filtresiyle kapsayan maç keşfi.
- Maç başına ev sahibi/beraberlik/deplasman yüzdeleri, önerilen bahis seçimi, oran ve güven skoru.
- Tarih, ülke/lig, bahis türü ve risk tercihiyle filtreleme.
- Sabit kupon üst sınırı olmadan, kullanıcının kuponda kaç maç olacağını belirleyebildiği otomatik kupon oluşturucu.
- Kullanıcının tek tek maç seçebilmesi veya modelin seçilen sayıya göre öneri üretmesi.
- Oluşturulan kuponun onaya sunulması; para yatırma, ödeme ve gerçek bahis sitesinde otomatik oynama yoktur.
- Tahminlerin garanti olmadığına dair görünür sorumlu kullanım açıklaması.
- Masaüstü ve mobil uyumlu veri yoğun analiz paneli.

## Uygulama yaklaşımı

- React + TypeScript + Tailwind ile tek sayfalı, duyarlı dashboard.
- Wouter ile `/` ana paneli ve gelecekte genişletilebilecek `/404` rotası.
- The Odds API canlı futbol akışı sunucu tarafında `THE_ODDS_API_KEY` korumalı sırrıyla kullanılır; aktif üst ve ikinci seviye ligler için 48 saatlik Avrupa h2h oranları alınır, oranlardan normalize piyasa olasılığı türetilir ve 5 dakikalık sunucu önbelleğiyle kota korunur. Bağlantı veya kota sorunu olursa arayüz açıkça demo etiketiyle örnek veri fallback’i kullanır.
- Otomatik kupon algoritması, kullanıcının risk seçimine göre güven puanı ve “değer” puanını ağırlıklandırıp istenen adet kadar maçı seçer.
- Gerçek sonuç geçmişi ve harici veri bağlantısı sonraki iterasyonda yönetilen veritabanı ve API hub/korumalı sağlayıcı bağlantısıyla eklenecek.

## Tasarım sistemi

### Design Movement

**Dark sports intelligence / editorial control-room**: spor yayıncılığı yoğunluğunu veri terminali netliğiyle birleştiren, premium ama bahis sitesi klişelerinden uzak bir analiz yüzeyi.

### Core Principles

1. **Sinyal önce:** Önemli olasılık, öneri ve güven bilgisi ilk bakışta okunur.
2. **Yoğun ama ferah:** Çok sayıda maçı kompakt satırlarda gösterirken güçlü boşluk ve hiyerarşi korunur.
3. **Şeffaf öneri:** “Model seçti” yerine güven, olasılık ve veri etiketi görünür kalır.
4. **Kullanıcı kontrolü:** Kupon adedi ve risk seçimi her zaman kullanıcıdadır; otomasyon sadece öneridir.

### Color Philosophy

Koyu lacivert arka plan uzun analiz oturumlarında sakin bir zemin oluşturur. Elektrik yeşili “pozitif sinyal” ve seçili kupon durumunu, buz mavisi analitik ölçümleri, amber ise belirsizliği temsil eder. Kırmızı yalnızca dikkat ve düşük güven için kullanılır.

### Layout Paradigm

Sol tarafta sabit dar bir navigasyon rayı, üstte bağlam ve tarih barı, merkezde büyük “bugünün tahtası” akışı, sağda kupon çalışma yüzeyi bulunur. Bu üç bölümlü kontrol odası düzeni, klasik merkezi kart grid’i yerine karar akışını öne çıkarır.

### Signature Elements

- “O” harfinden türeyen iki yaylı Oranix işareti ve küçük canlı sinyal noktası.
- Maç kartlarında yüzde değerlerinin altında ince güven çubukları.
- Seçili kupon bacağında yeşil kenar ışığı ve “MODEL” mikro etiketi.

### Interaction Philosophy & Animation

Filtre değişimlerinde içerik hafifçe yukarıdan yerine oturur; maç seçimi kartı ince yeşil çizgiyle vurgular. Hover durumları sessiz ve işlevsel, 150–220ms arasıdır. Kupon oluşturma butonu tıklandığında panelde kısa bir parıltı ve seçim sayısının güncellenmesi kullanılır; dikkat dağıtan sürekli hareket yoktur.

### Typography System

Başlıklarda **Space Grotesk**, gövde ve tablo bilgilerinde **Inter** tercih edilir. Başlıklar sıkı ve güçlü; sayısal değerler `tabular-nums` ve yüksek kontrastla gösterilir. Mikro etiketler büyük harf, harf aralığı artırılmış 10–11px ölçüsünde kullanılır.

### Brand Essence

**Dünyanın maçlarını tek bakışta karşılaştıran, açıklanabilir futbol analiz masası.** Kişilik: analitik, sakin, kararlı.

### Brand Voice

Net, ölçülü ve iddiasını veriye bağlayan dil.

- “Bugünün sinyallerini gürültüden ayır.”
- “Öneri istatistikseldir; karar her zaman sende.”

### Wordmark & Logo

“Oranix” kelimesindeki O, iki eş merkezli yay ve merkezde yeşil sinyal noktasıyla çizilir. Wordmark Space Grotesk SemiBold; ikon tek başına uygulama simgesi olarak çalışır.

### Signature Brand Color

**Signal Mint `#C9F27A`** — pozitif tahmin ve kullanıcı kontrolünü aynı anda çağrıştıran, koyu zeminde sahiplenilebilir parlaklık.

## Proje yapısı

- `client/src/pages/Home.tsx`: ana dashboard, filtreler, maç akışı, kupon çalışma yüzeyi.
- `client/src/index.css`: Oranix renk token’ları, tipografi, responsive layout ve kontrol odası görsel dili.
- `client/src/App.tsx`: route ve global sağlayıcılar.
- `public/manus-routes.json`: platform route manifest’i.
- `drizzle/schema.ts`: mevcut kullanıcı tablosu; sonraki iterasyonda tahmin/kupon geçmişi tabloları için genişletilecek.
- `server/routers.ts`: mevcut auth router; sonraki iterasyonda maç/veri prosedürleri burada tutulacak.

## Veri ve sınırlar

Canlı akış The Odds API’nin desteklediği ve aktif olan üst/ikinci seviye futbol liglerinden fikstür ve h2h oranlarını getirir. Bu sağlayıcı takım formu, sakatlık veya kadro verisini sunmadığı için canlı satırlar “piyasa olasılığı” olarak etiketlenir; kapsam sağlayıcının o anda aktif tuttuğu liglere bağlıdır. Demo veri, API bağlantısı başarısız olduğunda ürün akışını koruyan fallback’tir. Tahminler garanti değildir. Uygulama bahis sitesi hesabına bağlanmaz, para yatırmaz ve kuponu otomatik oynatmaz.

## Sunum ve çalıştırma

- Runtime: port 3000, yönetilen server + database mevcut.
- Geliştirme: `pnpm dev`.
- Kontrol: `pnpm check`, `pnpm build`.
- Önizleme route’ları: `/` ve `/404`.
