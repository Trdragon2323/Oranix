# Oranix MVP ToDo

## Global lig keşfi ve filtreleme

- Dünya genelindeki veri sağlayıcısının desteklediği en üst seviye ve 2. seviye futbol ligleri ülke/lig filtresiyle listelenmelidir.
- Kullanıcı tarih, ülke/lig, bahis türü ve risk tercihine göre maç listesini filtreleyebilmelidir.
- Maç listesi masaüstü ve mobil ekranlarda okunabilir olmalıdır.

## Tahmin ve maç analizi görünümü

- Her maç için ev sahibi, beraberlik ve deplasman yüzdesel olasılıkları gösterilmelidir.
- Her maç için önerilen seçim, oran, güven skoru ve veri durumu görünür olmalıdır.
- Tahminlerin garanti olmadığı ve istatistiksel analiz sunduğu açıkça belirtilmelidir.
- Türkiye ligi, sağlayıcıdaki `soccer_turkey_super_league` anahtarından `Türkiye / Süper Lig` olarak görünmelidir; sağlayıcıda maç yoksa demo satırı açıkça etiketlenmelidir.
- Maç detayında sağlayıcıda mevcutsa maç alt/üst, karşılıklı gol, ilk yarı ve ikinci yarı marketleri gerçek oranlarıyla gösterilmelidir; desteklenmeyen market için sahte oran üretilmemelidir.
- Canlı ve yakın zamanda biten maç skorları skor endpoint’inden alınmalı, canlı skor/gol bildirim alanında görünmelidir.

## Kullanıcı kontrollü otomatik kupon

- Kullanıcı kuponda kaç maç olacağını kendi belirleyebilmelidir; sabit uygulama üst sınırı dayatılmamalıdır.
- Kullanıcı tek tek maç seçebilmeli veya modelin seçilen maç adedine göre otomatik öneri üretmesini sağlayabilmelidir.
- Kupon özeti seçim, toplam oran, tahmini isabet ve risk bilgisini göstermelidir.
- Kupon kullanıcıya inceleme/onay için sunulmalı; gerçek bahis sitesinde otomatik oynama, para yatırma veya ödeme yapılmamalıdır.
- Üretilen kuponlar birbirinden ayrı kayıtlar olarak Kuponlarım görünümünde listelenmelidir.
- Kullanıcı düşük/dengeli yanında yüksek riskli kuponu da açıkça oluşturabilmelidir.
- Skorlar geldiğinde kupon ayağı sonuçları hesaplanmalı ve kupon `Tuttu`, `Yattı` veya `Bekliyor` olarak gösterilmelidir.

## Ürün temeli ve teslim

- Arayüz Türkçe, veri yoğun ve mobil uyumlu bir analiz paneli olarak sunulmalıdır.
- The Odds API canlı market/skor uçları sunucu üzerinden kullanılmalı; geçersiz veya kota dışı anahtar durumunda arayüz güvenli demo fallback göstermeli ve canlı veri varmış gibi davranmamalıdır.
- `/manus-routes.json` route manifest’i mevcut sayfaları doğru göstermelidir.
- `pnpm check` ve `pnpm build` başarıyla tamamlanmalıdır.
