# Oranix teslim ölçütleri

## Etkileşimli futbol analiz çalışma alanı
- [ ] Öncelikli ürün sınırları: Uygulama yalnızca futbol ile başlamalıdır. Uygulama gerçek bahis, ödeme, para yatırma, bahis hesabı bağlantısı ya da otomatik bahis gönderimi yapmamalıdır. Kuponlar yalnızca analiz ve kullanıcı incelemesi için taslak olarak kalmalıdır. Olasılıklar “kazanma garantisi” olarak sunulmamalıdır.
- [ ] Ana menüde Genel Bakış, Kuponlarım, Lig Merkezi ve Tahmin Geçmişi sekmeleri olmalı; her sekme kendi işlevsel içeriğini açmalıdır.
- [ ] Genel Bakış arama, tarih, ülke, lig, market ve risk filtreleri sunmalı; filtreler seçilen maçlar ve otomatik kupon üretimini gerçekten etkilemelidir. Türkiye ligleri görünür olmalı ve sağlayıcı anahtarları Türkçe normalleştirilmelidir. Sahte demo fikstürü kesinlikle gösterilmemelidir.
- [ ] Her maç kartında ülke, lig, seviye, başlangıç zamanı, takımlar, 1-X-2 olasılıkları, öneri, oran, güven puanı, risk etiketi ve verinin canlı sağlayıcıdan geldiği görünmelidir.
- [ ] Maç detayındaki event bazlı marketler sağlayıcının döndürdükleriyle sınırlı olmalıdır: maç alt/üst, karşılıklı gol, ilk yarı sonucu/alt-üst, ikinci yarı sonucu/alt-üst; veri yoksa “Bu market için veri yok” yazılmalıdır.
- [ ] Canlı skor yalnızca sağlayıcıdan alınan gerçek skorlarla çalışmalı, en az 60 saniyelik kontrollü yenileme aralığı kullanmalı ve canlı skor yoksa bunu dürüstçe belirtmelidir. Bildirim izni istenirse açık kullanıcı izni gerekir.
- [ ] Kullanıcı maç sayısını belirler; filtrelenen maç sayısı hedefin altındaysa anlaşılır uyarı verilir. Koruma, Dengeli, Riskli/Değer profilleri sıralamayı değiştirir. “Farklı kupon üret” aynı kombinasyonu yinelemez; açıklanabilir rotasyon uygular.
- [ ] Her kupon ayrı kayıt olarak Kuponlarım'da oluşturulma zamanı, profil/risk, maç sayısı, seçimler, toplam oran ve durumla görünür.
- [ ] Kupon geçmişi ilk sürümde yalnızca tarayıcı/cihaz saklamasıdır; kullanıcı hesabı, veritabanı ve cihazlar arası kalıcılık yoktur. Gerçek skor eşleştiğinde durum Tuttu/Yattı/Bekliyor kurallarına göre hesaplanır; doğrulanamayan ayak Bekliyor kalır.

## Sunucu, veri ve güvenlik
- [ ] Frontend React + TypeScript; backend Node.js + Express. `/api/health`, `/api/odds/soccer`, `/api/odds/event?sportKey=...&eventId=...`, `/api/odds/scores?sports=...` endpoint'leri vardır.
- [ ] API anahtarı yalnızca sunucu ortam değişkeninde saklanır; istemci kodu, Git geçmişi, log veya ekran görüntüsüne yazılmaz. Kullanıcı anahtarı sohbetten paylaşmaz.
- [ ] Sağlayıcının etkin futbol ligleri sorgulanır; yalnızca gerçek sağlayıcı desteği olan hedef üst/ikinci ligler gösterilir ve Türkiye Süper Lig atlanmaz. Market yoksa oran uydurulmaz.
- [ ] Maç sonucu olasılıkları implied probability üzerinden hesaplanır; bookmaker marjı normalize edilir ve 1-X-2 toplamı yaklaşık %100 olur. Yalnızca oran varsa etiket piyasa olasılığı olmalıdır.
- [ ] Event marketleri yalnızca kullanıcı maç detayını açtığında sunucu tarafından istenir. Skor endpoint'i kota dostu, kayıtlı kuponların gerektirdiği anahtarlarla ve cache ile çağrılır.
- [ ] API isteklerinde timeout, kontrollü retry, 429 için sınırlı backoff, istek gruplama, en az 5 dakika uygun cache ve same-key single-flight vardır.
- [ ] 401/429/5xx/zaman aşımı/eksik market uygulamayı çökertmez; canlı yerine doğru durum ve son veri zamanı bildirilir. Anahtar yok/yanlışsa etiketli demo fallback olabilir; demo canlı gibi gösterilmez.
- [ ] Tip güvenli maç/kupon modelleri kullanılır; kişisel veri ve sır loglanmaz.

## Yayına hazırlık ve doğrulama
- [ ] Kaynakta `package.json`, lockfile, `client`, `server`, yapılandırma ve gerekli yayın dosyaları yer alır; node_modules, dist ve sır içeren `.env` aktarılmaz.
- [ ] Hedef Render Node Web Service: `pnpm install --frozen-lockfile && pnpm build`, `pnpm start`, health path `/api/health`, sağlayıcı portu `PORT` üzerinden dinleme. Kaynak önce kullanıcı yetkili GitHub deposunda görünmeden deploy başlatılmaz.
- [ ] Render'da `THE_ODDS_API_KEY` yalnızca Secret/Environment Variables içinde bulunur. Kullanıcı GitHub/Render şifresi, 2FA kodu veya PAT'ini sohbette paylaşmaz.
- [ ] `pnpm check`, `pnpm build`, health endpoint, API fallback, client filtreleri, her görünüm, kupon rotasyonu ve sonuç durumları doğrulanır.
- [ ] Yayın URL'si ve TLS, ana sayfa, asset'ler ve `/api/health` Chrome/Firefox/Safari/Android Chrome/WebView'da test edilmelidir; mobilde viewport, dokunma hedefleri, yatay taşma, filtre, kupon modülü ve modal kontrol edilir.
- [ ] Teslim notu host'u, veri kaynağını, canlı/demo durumunu, environment variable adlarını (değerlerini değil), sınırlamaları ve test sonuçlarını söyler; uygulamanın bahis oynamadığı ve tahminlerin garanti olmadığı açıkça belirtilir.
