# Oranix

Türkçe futbol analiz masası ve kullanıcı onaylı kupon **taslakları**. Gerçek bahis oynatma, para yatırma/çekme, bahis hesabı bağlantısı ve otomatik kupon gönderimi bulunmaz. Hiçbir tahmin garanti değildir.

## Yerelde çalıştırma

Node.js 20+ ve pnpm 12 kullanın. `pnpm install --frozen-lockfile`, sonra `pnpm dev`; arayüz Vite ile, API Express ile çalışır. Üretim kontrolü için `pnpm check`, `pnpm build`, `pnpm start` kullanın.

## Canlı sağlayıcı verisi

Canlı veri için The Odds API hesabında geçerli plan ve sunucuya özel `THE_ODDS_API_KEY` ortam değişkeni gerekir. Anahtarı yalnızca Render Service → Environment/Secrets bölümüne yazın; `.env`, frontend, kaynak kontrolü, log veya sohbet içinde tutmayın. API anahtarı yoksa/geçersizse uygulama sahte maç göstermez; kullanıcıya canlı veri anahtarının eksik/geçersiz olduğu söylenir ve maç listesi boş kalır.

Uygulama sağlayıcının etkin futbol spor anahtarlarını yerel bir üst/ikinci lig allowlist'iyle daraltır. Bu nedenle yalnızca allowlist'teki etkin ligler gösterilir; veri/market sağlayıcıda yoksa uydurulmaz. Sağlayıcı planına ve ülke/market kapsamına göre live skor ya da event detay marketleri olmayabilir. Odds API'nin canlı skor kapsamı seçili liglerle sınırlıdır.

1-X-2 yüzdeleri her bookmaker için `1/oran` değerlerinin marjı normalize edilip ardından bookmaker sonuçları ortalanarak çıkarılır; karttaki oran ise karşılaştırılan en iyi fiyat olur. Bunlar implied probability değerleridir; bağımsız model, takım formu, sakatlık veya kadro bilgisi değildir. Event markets tek tek maç açıldığında alınır; aynı istekler beş dakikaya kadar cache edilir. Skor sorguları ilgili seçili maç kimlikleriyle yapılır ve en az 60 saniyelik istemci yenileme aralığı kullanır.

Kupon geçmişi giriş olmadan yalnızca bu tarayıcının `localStorage` alanında kalır; cihazlar arası senkronize olmaz, tarayıcı depolaması silinirse kaybolabilir. Taslak hiçbir üçüncü tarafa iletilmez.

## Render ayarı

- Runtime: Node.js
- Build: `pnpm install --frozen-lockfile && pnpm build`
- Start: `pnpm start`
- Health check: `/api/health`
- Port: Render'ın `PORT` değişkeninden okunur.
- Secret: `THE_ODDS_API_KEY` yalnızca sunucuda

Ücretsiz Render Web Service kullanılabilir fakat boşta uyuyabilir/soğuk başlangıç gecikmesi gösterebilir; 7/24 kullanılabilirlik ve veri sağlayıcısı API planı ayrıca değerlendirilmelidir.

## API

`GET /api/health`, `GET /api/odds/soccer`, `GET /api/odds/event?sportKey=...&eventId=...`, `GET /api/odds/scores?sports=...&eventIds=...`.

## Resmî sağlayıcı kapsamı

Provider endpoint ve market key'leri: [Sports and leagues](https://the-odds-api.com/sports-odds-data/sports-apis.html), [market key'leri](https://the-odds-api.com/sports-odds-data/betting-markets.html), [API v4 kılavuzu](https://the-odds-api.com/liveapi/guides/v4/). Kapalı, plan dışı veya bu sezon etkin olmayan ligler/marketler uygulamada uydurulmaz. Hiçbir DEMO fikstürü yoktur.
