import { cached } from './cache.js';
const BASE = 'https://api.the-odds-api.com/v4';
export const TOP_SECOND = new Set([
    'soccer_turkey_super_league', 'soccer_epl', 'soccer_efl_champ',
    'soccer_spain_la_liga', 'soccer_spain_segunda_division',
    'soccer_germany_bundesliga', 'soccer_germany_bundesliga2',
    'soccer_italy_serie_a', 'soccer_italy_serie_b', 'soccer_france_ligue_one',
    'soccer_france_ligue_two', 'soccer_netherlands_eredivisie',
    'soccer_portugal_primeira_liga', 'soccer_spl', 'soccer_belgium_first_div',
    'soccer_austria_bundesliga', 'soccer_greece_super_league',
    'soccer_denmark_superliga', 'soccer_sweden_allsvenskan',
    'soccer_sweden_superettan', 'soccer_norway_eliteserien',
    'soccer_switzerland_superleague', 'soccer_usa_mls',
    'soccer_brazil_campeonato', 'soccer_brazil_serie_b',
    'soccer_argentina_primera_division', 'soccer_chile_campeonato',
    'soccer_china_superleague', 'soccer_finland_veikkausliiga',
    'soccer_japan_j_league', 'soccer_korea_kleague1', 'soccer_australia_aleague',
    'soccer_mexico_ligamx', 'soccer_poland_ekstraklasa',
    'soccer_russia_premier_league', 'soccer_saudi_arabia_pro_league',
    'soccer_league_of_ireland',
]);
export const SECOND_TIER = new Set([
    'soccer_efl_champ', 'soccer_spain_segunda_division',
    'soccer_germany_bundesliga2', 'soccer_italy_serie_b',
    'soccer_france_ligue_two', 'soccer_brazil_serie_b',
    'soccer_sweden_superettan',
]);
const TURKISH = {
    soccer_turkey_super_league: 'Türkiye / Süper Lig',
    soccer_epl: 'İngiltere / Premier League',
    soccer_efl_champ: 'İngiltere / Championship',
    soccer_spain_la_liga: 'İspanya / La Liga',
    soccer_spain_segunda_division: 'İspanya / Segunda División',
    soccer_germany_bundesliga: 'Almanya / Bundesliga',
    soccer_germany_bundesliga2: 'Almanya / 2. Bundesliga',
    soccer_italy_serie_a: 'İtalya / Serie A',
    soccer_italy_serie_b: 'İtalya / Serie B',
    soccer_france_ligue_one: 'Fransa / Ligue 1',
    soccer_france_ligue_two: 'Fransa / Ligue 2',
    soccer_netherlands_eredivisie: 'Hollanda / Eredivisie',
    soccer_portugal_primeira_liga: 'Portekiz / Primeira Liga',
    soccer_spl: 'İskoçya / Premiership',
    soccer_belgium_first_div: 'Belçika / First Division A',
    soccer_austria_bundesliga: 'Avusturya / Bundesliga',
    soccer_greece_super_league: 'Yunanistan / Süper Lig',
    soccer_denmark_superliga: 'Danimarka / Superliga',
    soccer_sweden_allsvenskan: 'İsveç / Allsvenskan',
    soccer_sweden_superettan: 'İsveç / Superettan',
    soccer_norway_eliteserien: 'Norveç / Eliteserien',
    soccer_switzerland_superleague: 'İsviçre / Super League',
    soccer_usa_mls: 'ABD / MLS',
    soccer_brazil_campeonato: 'Brezilya / Série A',
    soccer_brazil_serie_b: 'Brezilya / Série B',
    soccer_argentina_primera_division: 'Arjantin / Primera División',
    soccer_chile_campeonato: 'Şili / Primera División',
    soccer_china_superleague: 'Çin / Süper Lig',
    soccer_finland_veikkausliiga: 'Finlandiya / Veikkausliiga',
    soccer_japan_j_league: 'Japonya / J1 League',
    soccer_korea_kleague1: 'Güney Kore / K League 1',
    soccer_australia_aleague: 'Avustralya / A-League',
    soccer_mexico_ligamx: 'Meksika / Liga MX',
    soccer_poland_ekstraklasa: 'Polonya / Ekstraklasa',
    soccer_russia_premier_league: 'Rusya / Premier League',
    soccer_saudi_arabia_pro_league: 'Suudi Arabistan / Pro League',
    soccer_league_of_ireland: 'İrlanda / Premier Division',
};
export function leagueTitle(key, fallback) {
    return TURKISH[key] ?? fallback;
}
export function providerErrorMessage(status) {
    if (status === 401)
        return 'Canlı veri anahtarı geçersiz veya yapılandırılmamış.';
    if (status === 403)
        return 'Sağlayıcı erişimi ya da plan kapsamı bu isteğe izin vermedi.';
    if (status === 404)
        return 'İstenen maç veya sağlayıcı kaydı bulunamadı.';
    if (status === 429)
        return 'Veri sağlayıcısının kota ya da hız sınırına ulaşıldı. Bir süre sonra yeniden deneyin.';
    if (status >= 500)
        return 'Canlı veri sağlayıcısı geçici olarak yanıt vermiyor. Yeniden deneyin.';
    return 'Canlı veri şu anda alınamıyor. Bir süre sonra yeniden deneyin.';
}
async function request(path, params = {}) {
    const key = process.env.THE_ODDS_API_KEY?.trim();
    if (!key)
        throw Object.assign(new Error('Provider configuration unavailable'), { status: 401, code: 'MISSING_API_KEY' });
    const url = new URL(BASE + path);
    url.searchParams.set('apiKey', key);
    for (const [name, value] of Object.entries(params))
        url.searchParams.set(name, value);
    const response = await fetch(url, { signal: AbortSignal.timeout(12_000) });
    if (!response.ok) {
        throw Object.assign(new Error(`Odds API HTTP ${response.status}`), { status: response.status });
    }
    return response.json();
}
export const sports = () => cached('sports', 300_000, () => request('/sports/'))
    .then(items => items.filter(sport => sport.active && sport.key.startsWith('soccer_') && TOP_SECOND.has(sport.key)));
export const odds = (sport) => cached(`odds:${sport}`, 300_000, () => request(`/sports/${encodeURIComponent(sport)}/odds/`, {
    regions: 'eu', markets: 'h2h', oddsFormat: 'decimal', dateFormat: 'iso',
}));
export const eventOdds = (sport, id) => cached(`event:${sport}:${id}`, 300_000, () => request(`/sports/${encodeURIComponent(sport)}/events/${encodeURIComponent(id)}/odds/`, {
    regions: 'eu', markets: 'h2h,totals,btts,h2h_h1,totals_h1,h2h_h2,totals_h2', oddsFormat: 'decimal',
}));
export const scores = (sport, eventIds = []) => cached(`scores:${sport}:${eventIds.slice().sort().join(',')}`, 60_000, () => request(`/sports/${encodeURIComponent(sport)}/scores/`, {
    daysFrom: '3', ...(eventIds.length ? { eventIds: eventIds.join(',') } : {}),
}));
function isValidPrice(value) {
    return typeof value === 'number' && Number.isFinite(value) && value > 1;
}
export function isValidOddsArray(value) {
    return Array.isArray(value)
        && value.length >= 3
        && value.every(price => price === null || (typeof price === 'number' && Number.isFinite(price)));
}
export function normalise(event) {
    if (!event || typeof event.home_team !== 'string' || typeof event.away_team !== 'string')
        return null;
    const bookmakers = Array.isArray(event.bookmakers) ? event.bookmakers : [];
    const rows = [];
    for (const bookmaker of bookmakers) {
        if (!bookmaker || typeof bookmaker.title !== 'string' || !Array.isArray(bookmaker.markets))
            continue;
        const market = bookmaker.markets.find(item => item?.key === 'h2h');
        if (!market || !Array.isArray(market.outcomes))
            continue;
        const outcomes = market.outcomes;
        const prices = [
            outcomes.find(outcome => outcome?.name === event.home_team)?.price,
            outcomes.find(outcome => outcome?.name === 'Draw')?.price,
            outcomes.find(outcome => outcome?.name === event.away_team)?.price,
        ];
        if (!prices.every(isValidPrice))
            continue;
        const typedPrices = [prices[0], prices[1], prices[2]];
        const inverse = typedPrices.map(price => 1 / price);
        const inverseTotal = inverse.reduce((sum, probability) => sum + probability, 0);
        if (!Number.isFinite(inverseTotal) || inverseTotal <= 0)
            continue;
        rows.push({
            book: bookmaker.title,
            prices: typedPrices,
            probabilities: inverse.map(probability => probability / inverseTotal),
            updatedAt: typeof market.last_update === 'string'
                ? market.last_update
                : typeof bookmaker.last_update === 'string' ? bookmaker.last_update : null,
        });
    }
    if (rows.length === 0)
        return null;
    const rounded = [0, 1, 2].map(index => Math.round(rows.reduce((sum, row) => sum + row.probabilities[index], 0) / rows.length * 100));
    const difference = 100 - rounded.reduce((sum, probability) => sum + probability, 0);
    const largestIndex = rounded.indexOf(Math.max(...rounded));
    rounded[largestIndex] += difference;
    const best = [0, 1, 2].map(index => rows.reduce((current, row) => row.prices[index] > current.prices[index] ? row : current, rows[0]));
    const odds = [
        best[0].prices[0], best[1].prices[1], best[2].prices[2],
    ];
    const bestBookmakers = [best[0].book, best[1].book, best[2].book];
    const updatedAt = rows.map(row => row.updatedAt).filter((value) => Boolean(value)).sort().at(-1) ?? null;
    return {
        odds,
        probabilities: rounded,
        bookmaker: [...new Set(bestBookmakers)].join(', '),
        bookmakers: bestBookmakers,
        bookmakerCount: rows.length,
        updatedAt,
    };
}
