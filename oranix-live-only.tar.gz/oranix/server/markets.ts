import type {Event} from './provider.js';

const MARKET_TITLES:Record<string,string>={h2h:'Maç sonucu',totals:'Toplam gol',btts:'Karşılıklı gol',h2h_h1:'İlk yarı sonucu',totals_h1:'İlk yarı toplam gol',h2h_h2:'İkinci yarı sonucu',totals_h2:'İkinci yarı toplam gol'};

type Offer={name:string;price:number;point?:number};
type Row={bookmaker:string;outcomes:Offer[]};

/** Aggregates only complete bookmaker books for the same market and goal line. */
export function normaliseEventMarkets(event:Event){
 const groups=new Map<string,{key:string;point?:number;rows:Row[]}>();
 for(const bookmaker of event.bookmakers??[])for(const market of bookmaker.markets??[]){
  const points=[...new Set(market.outcomes.map(o=>o.point))];
  for(const point of points){
   const outcomes=market.outcomes.filter(o=>o.point===point);
   if(outcomes.length<2||outcomes.some(o=>!Number.isFinite(o.price)||o.price<=1))continue;
   const id=`${market.key}:${point??'main'}`;
   const group=groups.get(id)??{key:market.key,point,rows:[]};
   group.rows.push({bookmaker:bookmaker.title,outcomes});groups.set(id,group);
  }
 }
 return [...groups.values()].map(group=>{
  const names=[...new Set(group.rows.flatMap(r=>r.outcomes.map(o=>o.name)))];
  const complete=group.rows.filter(r=>r.outcomes.length===names.length&&names.every(n=>r.outcomes.some(o=>o.name===n)));
  if(!complete.length)return null;
  const normalized=complete.map(r=>{const inverse=names.map(n=>1/r.outcomes.find(o=>o.name===n)!.price);const sum=inverse.reduce((a,b)=>a+b,0);return inverse.map(v=>v/sum)});
  const probabilities=names.map((_,i)=>Math.round(normalized.reduce((sum,row)=>sum+row[i],0)/normalized.length*100));
  probabilities[probabilities.indexOf(Math.max(...probabilities))]+=100-probabilities.reduce((a,b)=>a+b,0);
  const best=names.map(name=>complete.reduce((a,r)=>r.outcomes.find(o=>o.name===name)!.price>a.outcomes.find(o=>o.name===name)!.price?r:a,complete[0]));
  return{key:group.key,title:MARKET_TITLES[group.key]??group.key,point:group.point,bookmaker:[...new Set(best.map(x=>x.bookmaker))].join(', '),outcomes:names.map((name,i)=>({name,price:best[i].outcomes.find(o=>o.name===name)!.price,point:group.point,probability:probabilities[i],bestBookmaker:best[i].bookmaker}))};
 }).filter((x):x is NonNullable<typeof x>=>x!==null);
}
