import assert from 'node:assert/strict';
import test from 'node:test';
import {
  extractProviderErrorCode, normalise, providerErrorMessage, type Event,
} from './provider.js';

function eventWithBooks(books: unknown[]): Event {
  return {
    id: 'fixture-event',
    sport_key: 'soccer_turkey_super_league',
    sport_title: 'Süper Lig',
    commence_time: '2026-10-12T18:00:00Z',
    home_team: 'Ev Sahibi',
    away_team: 'Deplasman',
    bookmakers: books as Event['bookmakers'],
  };
}

function bookmaker(title: string, prices: unknown[], updatedAt = '2026-10-11T12:00:00Z') {
  return {
    key: title.toLowerCase().replaceAll(' ', '-'),
    title,
    last_update: updatedAt,
    markets: [{
      key: 'h2h',
      outcomes: [
        { name: 'Ev Sahibi', price: prices[0] },
        { name: 'Draw', price: prices[1] },
        { name: 'Deplasman', price: prices[2] },
      ],
    }],
  };
}

function normalisedBookProbabilities(prices: number[]): number[] {
  const inverse = prices.map(price => 1 / price);
  const total = inverse.reduce((sum, value) => sum + value, 0);
  return inverse.map(value => value / total);
}

test('best 1/X/2 prices are flat numbers and probabilities average each bookmaker normalisation', () => {
  const validBooks = [
    { title: 'Book A', prices: [2.0, 3.5, 3.9] },
    { title: 'Book B', prices: [2.2, 3.2, 4.4] },
  ];
  const result = normalise(eventWithBooks(validBooks.map(book => bookmaker(book.title, book.prices))));

  assert.ok(result);
  assert.deepEqual(result.odds, [2.2, 3.5, 4.4]);
  assert.ok(Array.isArray(result.odds));
  assert.equal(result.odds.length, 3);
  assert.ok(result.odds.every(price => typeof price === 'number' && Number.isFinite(price)));
  assert.deepEqual(result.bookmakers, ['Book B', 'Book A', 'Book B']);
  assert.equal(result.bookmakerCount, 2);

  const perBook = validBooks.map(book => normalisedBookProbabilities(book.prices));
  const expected = [0, 1, 2].map(index => Math.round(
    perBook.reduce((sum, probabilities) => sum + probabilities[index], 0) / perBook.length * 100,
  ));
  expected[expected.indexOf(Math.max(...expected))] += 100 - expected.reduce((sum, value) => sum + value, 0);
  assert.deepEqual(result.probabilities, expected);
  assert.equal(result.probabilities.reduce((sum, value) => sum + value, 0), 100);
});

test('a bookmaker with missing, invalid, non-numeric, or non-finite prices is excluded as a whole', () => {
  const good = bookmaker('Valid Book', [2.1, 3.4, 4.1]);
  const malformed = [
    bookmaker('String price', [2.0, '3.0', 4.0]),
    bookmaker('Zero price', [2.0, 0, 4.0]),
    bookmaker('At-or-below-one price', [2.0, 1, 4.0]),
    bookmaker('NaN price', [2.0, Number.NaN, 4.0]),
    {
      key: 'missing-outcome', title: 'Missing outcome', markets: [{ key: 'h2h', outcomes: [
        { name: 'Ev Sahibi', price: 2.0 }, { name: 'Draw', price: 3.0 },
      ] }],
    },
  ];
  const result = normalise(eventWithBooks([good, ...malformed]));

  assert.ok(result);
  assert.equal(result.bookmakerCount, 1);
  assert.deepEqual(result.bookmakers, ['Valid Book', 'Valid Book', 'Valid Book']);
  assert.deepEqual(result.odds, [2.1, 3.4, 4.1]);
  assert.deepEqual(result.probabilities, normalisedBookProbabilities([2.1, 3.4, 4.1])
    .map(value => Math.round(value * 100)));
});

test('returns no market when every bookmaker has an invalid 1X2 price', () => {
  const result = normalise(eventWithBooks([
    bookmaker('Invalid Book', [2.0, Number.NaN, 4.0]),
  ]));
  assert.equal(result, null);
});

test('classifies only allow-listed provider error codes without exposing response text', () => {
  assert.equal(extractProviderErrorCode('{"error":"OUT_OF_USAGE_CREDITS"}'), 'OUT_OF_USAGE_CREDITS');
  assert.equal(extractProviderErrorCode('{"error":"INVALID_KEY"}'), 'INVALID_KEY');
  assert.equal(extractProviderErrorCode('private provider response detail'), undefined);
  assert.equal(
    providerErrorMessage(401, 'OUT_OF_USAGE_CREDITS'),
    'The Odds API aylık kullanım kredisi dolmuş. Sağlayıcı hesabındaki kullanım ve plan bilgisini kontrol edin.',
  );
});
