type Entry<T>={value:T;expires:number};
const cache=new Map<string,Entry<unknown>>();
const pending=new Map<string,Promise<unknown>>();
export async function cached<T>(key:string,ttlMs:number,load:()=>Promise<T>):Promise<T>{
 const hit=cache.get(key) as Entry<T>|undefined;if(hit&&hit.expires>Date.now())return hit.value;
 const existing=pending.get(key) as Promise<T>|undefined;if(existing)return existing;
 const task=(async()=>{let last:unknown;for(let attempt=0;attempt<3;attempt++){try{const value=await load();cache.set(key,{value,expires:Date.now()+ttlMs});return value;}catch(error){last=error;const status=(error as {status?:number})?.status;if(status===401||status===403)break;if(status===429&&attempt<2)await new Promise(r=>setTimeout(r,Math.min(1500*2**attempt,4000)));else if(attempt<2)await new Promise(r=>setTimeout(r,350*2**attempt));}}throw last;})().finally(()=>pending.delete(key));pending.set(key,task);return task;
}
export function cacheAge(key:string){const e=cache.get(key);return e?Math.max(0,Date.now()-(e.expires-300_000)):null;}
