# Oranix — uygulama ve yayın planı

## Ürün yaklaşımı
Türkçe, mobil öncelikli futbol analiz ve kupon taslağı aracı. Gerçek bahis/ödeme/bahis hesabı bağlantısı/otomatik gönderim yok. Olasılıklar garanti değildir. Gerçek sağlayıcı odds verisinden piyasa marjı normalize edilerek hesaplanır; veri yoksa maç gösterilmez ve demo fallback yoktur. Canlı skor ve kupon ayağı sonucu yalnızca doğrulanmış provider event ID ve skorla hesaplanır.

## Mimari ve klasörler
- `client/src/`: React + TypeScript tek sayfa uygulaması; Genel Bakış, Kuponlarım, Lig Merkezi, Tahmin Geçmişi; filtreler, maç ayrıntıları, kupon profilleri.
- `server/`: Node.js + Express API, The Odds API v4 için sunucu tarafı adaptör, zaman aşımı, retry, 5 dakikalık cache ve single-flight.
- `public/`: web manifest ve route manifest.
- Uygulama Express tarafından statik build ile sunulabilir; Render Web Service üzerinde `PORT` dinlenir.
- Kupon kayıtları ilk sürümde açıkça bu cihazın `localStorage` alanında kalır; hesaplar arası senkronizasyon/kullanıcı hesabı yok.

## Veri davranışı
- THE_ODDS_API_KEY yalnızca hosting ortam değişkeni; frontend'e hiçbir zaman gönderilmez.
- Etkin futbol ligleri sağlayıcıdan keşfedilir, bilinen dünya üst/ikinci lig allowlist'iyle sınırlandırılır. Sağlayıcı market sunmuyorsa “Bu market için veri yok”.
- Maç sonucu olasılıkları 1/oran değerleri normalize edilerek hesaplanır; oranlar ve olasılıklar sadece odds sağlayıcısına atfedilir.
- API hatalarında çökme yerine açık durum bildirimi ve boş maç listesi; hiçbir sahte demo fallback yok. Skorlar en az 60 saniyede bir istemciden yenilenir; API tarafında cache vardır.

## Tasarım sistemi
- **Hareket:** çağdaş spor analitiği / Swiss editorial dashboard; yoğun ama sakin, hızlı taranabilir.
- **İlkeler:** veri kökenini görünür tut; yüksek bilgi yoğunluğunu hiyerarşiyle düzenle; mobilde ana aksiyonları başparmak erişiminde tut; riskleri renkle ama yalnız renkle değil metinle anlat.
- **Renk:** mürekkep lacivert zemin ve sıcak fildişi yüzey; ayırt edici Oranix elektrik yeşili, canlı veri ve seçili durumlar için; turuncu risk/uyarı vurgusu.
- **Yerleşim:** sol nav + geniş analiz çalışma alanı + masaüstünde sabit kupon özeti; mobilde alt gezinme ve erişilebilir kupon çalışma alanı.
- **İmza öğeleri:** OR monogramı/çapraz saha çizgisi; oran olasılığı için ince mikro-bar; veri kaynağı rozetleri.
- **Etkileşim/hareket:** filtreler anında uygular, kupon önerisi kullanıcı onayıyla eklenir; kısa 140–220 ms geçiş, prefers-reduced-motion desteği.
- **Tipografi:** Manrope başlıklar, Inter arayüz/metin, sayısal oranlarda tabular numerals.
- **Marka:** Oranları açıklanabilir biçimde karşılaştıran, kuponu taslak olarak bırakan futbol analiz masası. Kişilik: analitik, dürüst, çevik.
- **Ses:** kısa, ölçülü, garanti vermeyen. Örnek: “Oran değil, önce olasılık.” / “Taslağını hazırla; karar sende.”
- **Wordmark:** özel O halkası içine yerleştirilmiş saha çizgisi ve bitişik geometrik ORANIX yazısı.
- **Marka rengi:** Oranix lime `#BEF264`.

## Yayın
İstenen hedef: GitHub'daki kullanıcı yetkili deposu → Render Node Web Service. Kullanıcı GitHub/Render oturum açma ve depo erişimini kendi tarayıcısında sağlamalı; parola, 2FA veya token sohbetten istenmez. Ücretsiz Render planı ilk test için varsayılır; uyku/soğuk başlangıç ve devamlılık sınırlaması açıkça iletilir. `THE_ODDS_API_KEY` Render Dashboard Secrets/Environment Variables bölümünde kullanıcı tarafından girilir; değer sohbet ya da kaynak koda alınmaz. Özel alan adı varsayılan olarak yoktur.
