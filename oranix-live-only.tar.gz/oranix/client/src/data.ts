import type {Match} from './types';
export async function loadMatches(){const r=await fetch('/api/odds/soccer');return r.json();}
export async function loadEvent(match:Match){const q=new URLSearchParams({sportKey:match.sportKey,eventId:match.providerId});const r=await fetch(`/api/odds/event?${q}`);return r.json();}
export async function loadScores(keys:string[],eventIds:string[]=[]){const q=new URLSearchParams({sports:keys.join(',')});if(eventIds.length)q.set('eventIds',eventIds.join(','));const r=await fetch(`/api/odds/scores?${q}`);return r.json();}
