type SuccessEntry = { kind: 'success'; value: unknown; expires: number; storedAt: number };
type FailureEntry = { kind: 'failure'; error: unknown; expires: number; storedAt: number };
type Entry = SuccessEntry | FailureEntry;

const cache = new Map<string, Entry>();
const pending = new Map<string, Promise<unknown>>();

const FAILURE_CACHE_MS = 15 * 60_000;
const TRANSIENT_FAILURE_CACHE_MS = 60_000;

export async function cached<T>(key: string, ttlMs: number, load: () => Promise<T>): Promise<T> {
  const now = Date.now();
  const hit = cache.get(key);
  if (hit && hit.expires > now) {
    if (hit.kind === 'failure') throw hit.error;
    return hit.value as T;
  }
  if (hit) cache.delete(key);

  const existing = pending.get(key) as Promise<T> | undefined;
  if (existing) return existing;

  const task = (async () => {
    let last: unknown;
    for (let attempt = 0; attempt < 3; attempt += 1) {
      try {
        const value = await load();
        cache.set(key, {
          kind: 'success',
          value,
          expires: Date.now() + ttlMs,
          storedAt: Date.now(),
        });
        return value;
      } catch (error) {
        last = error;
        const status = (error as { status?: number })?.status;
        const retryable = status === 429 || status === undefined || status >= 500;
        if (!retryable || attempt === 2) break;
        const delay = status === 429
          ? Math.min(1_500 * 2 ** attempt, 4_000)
          : 350 * 2 ** attempt;
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }

    const status = (last as { status?: number })?.status;
    const failureTtl = status === 401 || status === 403
      ? Math.min(ttlMs, FAILURE_CACHE_MS)
      : Math.min(ttlMs, TRANSIENT_FAILURE_CACHE_MS);
    cache.set(key, {
      kind: 'failure',
      error: last,
      expires: Date.now() + failureTtl,
      storedAt: Date.now(),
    });
    throw last;
  })().finally(() => pending.delete(key));

  pending.set(key, task);
  return task;
}

export function cacheAge(key: string): number | null {
  const entry = cache.get(key);
  return entry ? Math.max(0, Date.now() - entry.storedAt) : null;
}
