import express from 'express';
import helmet from 'helmet';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  eventOdds, isValidOddsArray, leagueTitle, normalise, odds, providerErrorMessage,
  scores, SECOND_TIER, sports, TOP_SECOND,
  type ProviderErrorCode,
} from './provider.js';
import { normaliseEventMarkets } from './markets.js';

const app = express();
const port = Number(process.env.PORT) || 3001;
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const safeEventId = /^[A-Za-z0-9_-]{1,128}$/;

app.disable('x-powered-by');
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' }, contentSecurityPolicy: false }));
app.use(express.json({ limit: '20kb' }));

app.get('/api/health', (_req, res) => res.json({
  ok: true,
  service: 'oranix',
  time: new Date().toISOString(),
  provider: process.env.THE_ODDS_API_KEY?.trim() ? 'configured' : 'missing',
  bettingEnabled: false,
}));

app.get('/api/odds/soccer', async (_req, res) => {
  try {
    const leagues = await sports();
    const results: Array<{
      sport: (typeof leagues)[number];
      events: Awaited<ReturnType<typeof odds>>;
      error?: boolean;
      errorStatus?: number;
      missingKey?: boolean;
      providerCode?: ProviderErrorCode;
    }> = [];

    for (let index = 0; index < leagues.length; index += 4) {
      const batch = await Promise.all(leagues.slice(index, index + 4).map(async sport => {
        try {
          return { sport, events: await odds(sport.key) };
        } catch (error) {
          const failure = error as { status?: number; code?: string; providerCode?: ProviderErrorCode };
          return {
            sport,
            events: [],
            error: true,
            errorStatus: failure.status,
            missingKey: failure.code === 'MISSING_API_KEY',
            providerCode: failure.providerCode,
          };
        }
      }));
      results.push(...batch);
      if (batch.some(result => result.missingKey || [401, 403, 429].includes(result.errorStatus ?? 0))) break;
    }

    const matches = results.flatMap(({ sport, events }) => events.map(event => {
      const market = normalise(event);
      if (!market || !isValidOddsArray(market.odds)) return null;
      const league = leagueTitle(sport.key, sport.title);
      const confidence = Math.max(...market.probabilities);
      return {
        providerId: event.id,
        sportKey: sport.key,
        league,
        country: league.split(' / ')[0],
        tier: SECOND_TIER.has(sport.key) ? '2' : '1',
        startTime: event.commence_time,
        home: event.home_team,
        away: event.away_team,
        source: 'live' as const,
        ...market,
        confidence,
        risk: confidence >= 55 ? 'Düşük' : confidence >= 43 ? 'Orta' : 'Yüksek',
        recommendation: ['1', 'X', '2'][market.probabilities.indexOf(confidence)],
      };
    })).filter(match => match !== null)
      .sort((left, right) => Date.parse(left.startTime) - Date.parse(right.startTime));

    const failures = results.filter(result => result.error).length;
    const firstFailure = results.find(result => result.error);
    const errorMessage = failures
      ? firstFailure?.missingKey
        ? 'Render ortamında THE_ODDS_API_KEY eksik veya boş.'
        : firstFailure?.errorStatus
          ? providerErrorMessage(firstFailure.errorStatus, firstFailure.providerCode)
          : `${failures} lig için canlı oran alınamadı; kota, anahtar veya sağlayıcı kapsamını kontrol edin.`
      : undefined;
    res.json({
      source: failures === results.length && failures > 0 ? 'unavailable' : 'live',
      fetchedAt: new Date().toISOString(),
      leagues: leagues.map(sport => {
        const title = leagueTitle(sport.key, sport.title);
        return {
          key: sport.key,
          title,
          country: title.split(' / ')[0],
          tier: SECOND_TIER.has(sport.key) ? '2' : '1',
          group: sport.group,
        };
      }),
      matches,
      errors: failures,
      error: errorMessage,
    });
  } catch (error) {
    const failure = error as { status?: number; code?: string; providerCode?: ProviderErrorCode };
    const status = failure.status ?? 503;
    res.status(200).json({
      source: 'unavailable',
      fetchedAt: new Date().toISOString(),
      error: failure.code === 'MISSING_API_KEY'
        ? 'Render ortamında THE_ODDS_API_KEY eksik veya boş.'
        : providerErrorMessage(status, failure.providerCode),
      matches: [],
      leagues: [],
    });
  }
});

app.get('/api/odds/event', async (req, res) => {
  const sportKey = typeof req.query.sportKey === 'string' ? req.query.sportKey : '';
  const eventId = typeof req.query.eventId === 'string' ? req.query.eventId : '';
  if (!TOP_SECOND.has(sportKey) || !safeEventId.test(eventId)) {
    return res.status(400).json({ error: 'Geçersiz maç/lig bilgisi' });
  }

  try {
    const event = await eventOdds(sportKey, eventId);
    if (!event) return res.json({ source: 'live', markets: [] });
    return res.json({ source: 'live', markets: normaliseEventMarkets(event) });
  } catch (error) {
    const failure = error as { status?: number; code?: string; providerCode?: ProviderErrorCode };
    const status = failure.status ?? 503;
    return res.status(200).json({
      source: 'unavailable',
      markets: [],
      error: failure.code === 'MISSING_API_KEY'
        ? 'Render ortamında THE_ODDS_API_KEY eksik veya boş.'
        : providerErrorMessage(status, failure.providerCode),
    });
  }
});

app.get('/api/odds/scores', async (req, res) => {
  const requestedSports = typeof req.query.sports === 'string' ? req.query.sports : '';
  const keys = [...new Set(requestedSports.split(',').filter(key => TOP_SECOND.has(key)))].slice(0, 4);
  if (keys.length === 0) return res.json({ source: 'live', scores: [], updatedAt: new Date().toISOString() });

  const requestedIds = typeof req.query.eventIds === 'string' ? req.query.eventIds.split(',') : [];
  const eventIds = [...new Set(requestedIds.filter(id => safeEventId.test(id)))].slice(0, 20);
  if (eventIds.length === 0) return res.json({ source: 'live', scores: [], updatedAt: new Date().toISOString() });

  const data: Array<{
    sport: string;
    items: Awaited<ReturnType<typeof scores>>;
    failure?: { status?: number; providerCode?: ProviderErrorCode };
  }> = [];
  for (const sport of keys) {
    try {
      data.push({ sport, items: await scores(sport, eventIds) });
    } catch (error) {
      const failure = error as { status?: number; providerCode?: ProviderErrorCode };
      data.push({ sport, items: [], failure });
      break;
    }
  }

  const successful = data.some(result => !result.failure);
  const firstFailure = data.find(result => result.failure)?.failure;
  return res.json({
    source: successful ? 'live' : 'unavailable',
    scores: data.flatMap(result => result.items.map(score => ({ ...score, sportKey: result.sport }))),
    error: firstFailure ? providerErrorMessage(firstFailure.status ?? 503, firstFailure.providerCode) : undefined,
    updatedAt: new Date().toISOString(),
  });
});

app.use(express.static(path.join(root, 'dist')));
app.get('/{*path}', (req, res, next) => req.path.startsWith('/api/')
  ? next()
  : res.sendFile(path.join(root, 'dist', 'index.html')));
app.listen(port, '0.0.0.0', () => console.log(`Oranix listening on ${port}`));
