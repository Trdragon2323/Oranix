import assert from 'node:assert/strict';
import test from 'node:test';
import { cacheAge, cached } from './cache.js';

let keyCounter = 0;
const uniqueKey = (prefix: string) => `${prefix}:${Date.now()}:${keyCounter += 1}`;

test('coalesces concurrent loads for the same cache key', async () => {
  const key = uniqueKey('coalesce');
  let calls = 0;
  let release!: () => void;
  const gate = new Promise<void>(resolve => { release = resolve; });
  const loader = async () => {
    calls += 1;
    await gate;
    return { source: 'live' };
  };

  const first = cached(key, 10_000, loader);
  const second = cached(key, 10_000, loader);
  release();

  assert.deepEqual(await Promise.all([first, second]), [
    { source: 'live' },
    { source: 'live' },
  ]);
  assert.equal(calls, 1);
  assert.notEqual(cacheAge(key), null);
});

test('caches provider authorization/quota failures to avoid repeated upstream calls', async () => {
  const key = uniqueKey('provider-failure');
  const failure = Object.assign(new Error('safe test failure'), { status: 401 });
  let calls = 0;
  const reject = async () => {
    calls += 1;
    throw failure;
  };

  await assert.rejects(cached(key, 15 * 60_000, reject), failure);
  await assert.rejects(cached(key, 15 * 60_000, async () => {
    calls += 1;
    return 'should-not-run';
  }), failure);

  assert.equal(calls, 1);
  assert.notEqual(cacheAge(key), null);
});
