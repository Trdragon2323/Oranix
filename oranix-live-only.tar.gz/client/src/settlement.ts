import type { Coupon, CouponLeg } from './types';

export type ProviderScore = {
  scores?: Array<{ name: string; score: string }>;
  completed: boolean;
  last_update: string | null;
};

export function updateLegFromProviderScore(leg: CouponLeg, providerScore: ProviderScore): CouponLeg {
  if ((leg.resultStatus ?? 'Bekliyor') !== 'Bekliyor' || !providerScore.scores?.length) return leg;

  const homeScore = Number(providerScore.scores.find(item => item.name === leg.home)?.score);
  const awayScore = Number(providerScore.scores.find(item => item.name === leg.away)?.score);
  if (!Number.isFinite(homeScore) || !Number.isFinite(awayScore)) return leg;

  const score: NonNullable<CouponLeg['score']> = {
    home: homeScore,
    away: awayScore,
    state: providerScore.completed ? 'SONUÇ' : 'CANLI',
    updatedAt: providerScore.last_update ?? null,
  };
  if (!providerScore.completed) return { ...leg, score };

  let actual: string | undefined;
  if (leg.marketKey === 'h2h') {
    actual = homeScore > awayScore ? '1' : homeScore < awayScore ? '2' : 'X';
  } else if (leg.marketKey === 'btts') {
    actual = homeScore > 0 && awayScore > 0 ? 'Yes' : 'No';
  } else if (leg.marketKey === 'totals' && leg.marketLine !== undefined) {
    const total = homeScore + awayScore;
    actual = total > leg.marketLine ? `Over ${leg.marketLine}` : total < leg.marketLine ? `Under ${leg.marketLine}` : 'Push';
  }

  if (!actual || actual === 'Push') return { ...leg, score };
  return { ...leg, score, resultStatus: actual === leg.selection ? 'Tuttu' : 'Yattı' };
}

export function deriveCouponStatus(legs: CouponLeg[]): Coupon['status'] {
  if (legs.some(leg => leg.resultStatus === 'Yattı')) return 'Yattı';
  if (legs.length > 0 && legs.every(leg => leg.resultStatus === 'Tuttu')) return 'Tuttu';
  return 'Bekliyor';
}
