import assert from 'node:assert/strict';
import test from 'node:test';
import type { CouponLeg } from './types';
import { deriveCouponStatus, updateLegFromProviderScore } from './settlement';

function leg(overrides: Partial<CouponLeg> = {}): CouponLeg {
  return {
    matchId: 'event-1',
    sportKey: 'soccer_epl',
    home: 'Home',
    away: 'Away',
    league: 'League',
    startTime: '2026-10-11T18:00:00.000Z',
    selection: '1',
    market: 'Maç sonucu',
    marketKey: 'h2h',
    odd: 1.8,
    probability: 56,
    source: 'live',
    resultStatus: 'Bekliyor',
    ...overrides,
  };
}

const score = (home: number, away: number, completed: boolean) => ({
  scores: [{ name: 'Home', score: String(home) }, { name: 'Away', score: String(away) }],
  completed,
  last_update: '2026-10-11T18:30:00.000Z',
});

test('live score is saved without marking a match as won before it is complete', () => {
  const updated = updateLegFromProviderScore(leg(), score(1, 0, false));
  assert.deepEqual(updated.score, { home: 1, away: 0, state: 'CANLI', updatedAt: '2026-10-11T18:30:00.000Z' });
  assert.equal(updated.resultStatus, 'Bekliyor');
});

test('completed correct home/draw/away selections are marked Tuttu', () => {
  assert.equal(updateLegFromProviderScore(leg(), score(2, 1, true)).resultStatus, 'Tuttu');
  assert.equal(updateLegFromProviderScore(leg({ selection: 'X' }), score(1, 1, true)).resultStatus, 'Tuttu');
  assert.equal(updateLegFromProviderScore(leg({ selection: '2' }), score(0, 3, true)).resultStatus, 'Tuttu');
});

test('completed wrong result is marked Yattı and keeps the final score', () => {
  const updated = updateLegFromProviderScore(leg(), score(0, 2, true));
  assert.equal(updated.resultStatus, 'Yattı');
  assert.deepEqual(updated.score, { home: 0, away: 2, state: 'SONUÇ', updatedAt: '2026-10-11T18:30:00.000Z' });
});

test('BTTS and totals markets settle against final scores', () => {
  assert.equal(updateLegFromProviderScore(leg({ marketKey: 'btts', selection: 'Yes' }), score(1, 1, true)).resultStatus, 'Tuttu');
  assert.equal(updateLegFromProviderScore(leg({ marketKey: 'totals', marketLine: 2.5, selection: 'Over 2.5' }), score(2, 1, true)).resultStatus, 'Tuttu');
  const push = updateLegFromProviderScore(leg({ marketKey: 'totals', marketLine: 2, selection: 'Over 2' }), score(1, 1, true));
  assert.equal(push.resultStatus, 'Bekliyor');
  assert.equal(push.score?.state, 'SONUÇ');
});

test('coupon is Tuttu only when every leg is Tuttu; a loss takes precedence', () => {
  assert.equal(deriveCouponStatus([leg({ resultStatus: 'Tuttu' }), leg({ resultStatus: 'Tuttu' })]), 'Tuttu');
  assert.equal(deriveCouponStatus([leg({ resultStatus: 'Tuttu' }), leg({ resultStatus: 'Bekliyor' })]), 'Bekliyor');
  assert.equal(deriveCouponStatus([leg({ resultStatus: 'Tuttu' }), leg({ resultStatus: 'Yattı' })]), 'Yattı');
});
