import assert from 'node:assert/strict';
import test from 'node:test';
import type { Coupon, Match } from './types';
import { buildAutomaticDraft, isUpcomingMatch } from './drafting';

const now = Date.parse('2026-10-11T18:00:00.000Z');

function match(
  id: string,
  startTime: string,
  probabilities: [number, number, number],
  odds: [number, number, number],
): Match {
  return {
    providerId: id,
    sportKey: 'soccer_epl',
    league: 'İngiltere / Premier League',
    country: 'İngiltere',
    tier: '1',
    startTime,
    home: `Ev ${id}`,
    away: `Deplasman ${id}`,
    source: 'live',
    odds,
    probabilities,
    bookmaker: 'Bookmaker',
    bookmakers: ['Bookmaker', 'Bookmaker', 'Bookmaker'],
    bookmakerCount: 1,
    updatedAt: null,
    confidence: Math.max(...probabilities),
    risk: 'Orta',
    recommendation: '1',
    availableMarkets: ['h2h'],
  };
}

const favorite = match('favorite', '2026-10-11T19:00:00.000Z', [68, 20, 12], [1.45, 4.2, 7.5]);
const balanced = match('balanced', '2026-10-11T20:00:00.000Z', [48, 28, 24], [2.0, 3.3, 3.7]);
const started = match('started', '2026-10-11T17:59:59.000Z', [70, 18, 12], [1.4, 4.5, 8]);

test('started, current-time, and invalid kickoff times are excluded', () => {
  assert.equal(isUpcomingMatch('2026-10-11T18:00:00.000Z', now), false);
  assert.equal(isUpcomingMatch(started.startTime, now), false);
  assert.equal(isUpcomingMatch('not-a-date', now), false);
  assert.equal(isUpcomingMatch(favorite.startTime, now), true);
});

test('automatic low-risk draft picks the highest-probability result and excludes started matches', () => {
  const draft = buildAutomaticDraft([started, balanced, favorite], 'all', 'Düşük Risk', 2, now);
  assert.equal(draft.availableCount, 2);
  assert.equal(draft.legs.length, 2);
  assert.deepEqual(draft.legs.map(leg => leg.matchId), ['favorite', 'balanced']);
  assert.equal(draft.legs[0].selection, '1');
  assert.equal(draft.legs.some(leg => leg.matchId === 'started'), false);
});

test('medium-risk profile selects a result near the balanced market probability', () => {
  const draft = buildAutomaticDraft([favorite, balanced], 'h2h', 'Orta Risk', 1, now);
  assert.equal(draft.legs[0].matchId, 'balanced');
  assert.equal(draft.legs[0].selection, '1');
  assert.equal(draft.legs[0].probability, 48);
});

test('risky profile prefers a higher-odds outcome near the risk target', () => {
  const draft = buildAutomaticDraft([favorite, balanced], 'h2h', 'Riskli', 1, now);
  assert.equal(draft.legs[0].matchId, 'balanced');
  assert.equal(draft.legs[0].selection, 'X');
  assert.equal(draft.legs[0].odd, 3.3);
});

test('requested leg count is capped at available upcoming matches', () => {
  const draft = buildAutomaticDraft([started, favorite], 'h2h', 'Düşük Risk', 5, now);
  assert.equal(draft.availableCount, 1);
  assert.equal(draft.legs.length, 1);
});

test('legacy coupon profiles remain valid during migration', () => {
  const legacyProfile: Coupon['profile'] = 'Dengeli';
  const draft = buildAutomaticDraft([balanced], 'h2h', legacyProfile, 1, now);
  assert.equal(draft.legs[0].selection, '1');
});
