import type { Coupon, CouponLeg, Match } from './types';

export type DraftQuote = {
  selection: string;
  market: string;
  marketKey: string;
  marketLine?: number;
  odd: number;
  probability: number;
  bookmaker?: string;
};

export type DraftProfile = 'Düşük Risk' | 'Orta Risk' | 'Riskli';

const labels = ['1', 'X', '2'];
const marketTitles: Record<string, string> = {
  h2h: 'Maç sonucu',
  totals: 'Alt / Üst',
  btts: 'Karşılıklı gol',
};

export function isUpcomingMatch(startTime: string, now = Date.now()): boolean {
  const kickoff = Date.parse(startTime);
  return Number.isFinite(kickoff) && kickoff > now;
}

export function quotesFor(match: Match, key: string): DraftQuote[] {
  if (key === 'h2h') {
    return labels.map((selection, index) => ({
      selection,
      market: marketTitles.h2h,
      marketKey: 'h2h',
      odd: match.odds[index] ?? 0,
      probability: match.probabilities[index] ?? 0,
      bookmaker: match.bookmakers?.[index],
    })).filter(quote => quote.odd > 1 && quote.probability > 0);
  }

  const title = marketTitles[key] ?? key;
  return (match.marketQuotes ?? [])
    .filter(market => market.key === key)
    .flatMap(market => market.outcomes.map(outcome => ({
      selection: `${outcome.name}${outcome.point !== undefined ? ` ${outcome.point}` : ''}`,
      market: title,
      marketKey: key,
      marketLine: outcome.point,
      odd: outcome.price,
      probability: outcome.probability ?? 0,
      bookmaker: outcome.bestBookmaker ?? market.bookmaker,
    })))
    .filter(quote => quote.odd > 1 && quote.probability > 0);
}

function canonicalProfile(profile: Coupon['profile']): DraftProfile {
  if (profile === 'Koruma') return 'Düşük Risk';
  if (profile === 'Dengeli') return 'Orta Risk';
  if (profile === 'Riskli / Değer') return 'Riskli';
  return profile;
}

function chooseQuote(quotes: DraftQuote[], profile: DraftProfile): DraftQuote {
  let choices = [...quotes];
  if (profile === 'Düşük Risk') {
    choices.sort((a, b) => b.probability - a.probability || a.odd - b.odd);
  } else if (profile === 'Orta Risk') {
    choices.sort((a, b) => Math.abs(a.probability - 48) - Math.abs(b.probability - 48) || b.probability - a.probability);
  } else {
    const higherOdds = choices.filter(quote => quote.odd >= 2.3);
    if (higherOdds.length) choices = higherOdds;
    choices.sort((a, b) => Math.abs(a.probability - 30) - Math.abs(b.probability - 30) || b.odd - a.odd);
  }
  return choices[0];
}

function compareCandidates(
  left: { match: Match; quote: DraftQuote },
  right: { match: Match; quote: DraftQuote },
  profile: DraftProfile,
): number {
  if (profile === 'Düşük Risk') {
    return right.quote.probability - left.quote.probability
      || Date.parse(left.match.startTime) - Date.parse(right.match.startTime);
  }
  if (profile === 'Orta Risk') {
    return Math.abs(left.quote.probability - 48) - Math.abs(right.quote.probability - 48)
      || Date.parse(left.match.startTime) - Date.parse(right.match.startTime);
  }
  return Math.abs(left.quote.probability - 30) - Math.abs(right.quote.probability - 30)
    || right.quote.odd - left.quote.odd
    || Date.parse(left.match.startTime) - Date.parse(right.match.startTime);
}

export function buildAutomaticDraft(
  matches: Match[],
  market: string,
  profile: Coupon['profile'],
  requestedCount: number,
  now = Date.now(),
  rotation = 0,
): { legs: CouponLeg[]; availableCount: number } {
  const key = market === 'all' ? 'h2h' : market;
  const riskProfile = canonicalProfile(profile);
  const ranked = matches
    .filter(match => isUpcomingMatch(match.startTime, now))
    .map(match => {
      const quotes = quotesFor(match, key);
      return quotes.length ? { match, quote: chooseQuote(quotes, riskProfile) } : null;
    })
    .filter((candidate): candidate is { match: Match; quote: DraftQuote } => candidate !== null)
    .sort((a, b) => compareCandidates(a, b, riskProfile));

  const count = Math.min(ranked.length, Math.max(1, Math.trunc(requestedCount) || 1));
  const maxOffset = Math.min(2, Math.max(0, ranked.length - count));
  const offset = maxOffset ? Math.max(0, Math.trunc(rotation) || 0) % (maxOffset + 1) : 0;
  const selected = ranked.slice(offset, offset + count);
  const legs = selected.map(({ match, quote }): CouponLeg => ({
    matchId: match.providerId,
    sportKey: match.sportKey,
    home: match.home,
    away: match.away,
    league: match.league,
    startTime: match.startTime,
    selection: quote.selection,
    market: quote.market,
    marketKey: quote.marketKey,
    marketLine: quote.marketLine,
    odd: quote.odd,
    probability: quote.probability,
    source: 'live',
  }));
  return { legs, availableCount: ranked.length };
}
